# ⚡ LA MECA CHAMPS 2 — Sistema de Gestión de Torneo

**Stack:** React + Tailwind CSS (frontend) · Node.js + Express (backend) · MongoDB + Mongoose (base de datos)

---

## 📁 ESTRUCTURA DEL PROYECTO

```
mecachamps/
├── backend/
│   ├── middleware/
│   │   ├── auth.js          ← JWT middleware
│   │   └── upload.js        ← Multer para imágenes
│   ├── models/
│   │   ├── Team.js
│   │   ├── Player.js
│   │   ├── Match.js
│   │   ├── News.js
│   │   └── Copa.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── teams.js
│   │   ├── players.js
│   │   ├── matches.js
│   │   ├── stats.js
│   │   ├── copa.js
│   │   └── news.js
│   ├── uploads/             ← imágenes subidas (se crea automáticamente)
│   ├── .env
│   ├── server.js
│   ├── seed.js
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Navbar.jsx
    │   │   ├── MatchCard.jsx
    │   │   ├── PlayerCard.jsx
    │   │   └── StandingsTable.jsx
    │   ├── context/
    │   │   └── AuthContext.jsx
    │   ├── pages/
    │   │   ├── Home.jsx
    │   │   ├── Login.jsx
    │   │   ├── PrimeraDivision.jsx
    │   │   ├── SegundaDivision.jsx
    │   │   ├── Copa.jsx
    │   │   ├── Teams.jsx
    │   │   ├── TeamDetail.jsx
    │   │   ├── NewsPage.jsx
    │   │   ├── NewsDetail.jsx
    │   │   ├── Estadisticas.jsx
    │   │   └── admin/
    │   │       ├── AdminDashboard.jsx
    │   │       ├── AdminTeams.jsx
    │   │       ├── AdminPlayers.jsx
    │   │       ├── AdminMatches.jsx
    │   │       ├── AdminFixture.jsx
    │   │       ├── AdminCopa.jsx
    │   │       └── AdminNews.jsx
    │   ├── App.jsx
    │   ├── api.js
    │   ├── index.css
    │   └── main.jsx
    ├── index.html
    ├── vite.config.js
    ├── tailwind.config.js
    └── package.json
```

---

## 🚀 INSTRUCCIONES DE INSTALACIÓN

### Requisitos previos
- **Node.js** v18+ → https://nodejs.org
- **MongoDB** → https://www.mongodb.com/try/download/community (local) o una URI de MongoDB Atlas

---

### PASO 1 — Clonar / descomprimir el proyecto

Colocá el proyecto en una carpeta. Debería quedar:
```
mecachamps/
  backend/
  frontend/
```

---

### PASO 2 — Configurar el Backend

```bash
cd mecachamps/backend
npm install
```

Editá el archivo `.env` si es necesario:
```env
MONGO_URI=mongodb://localhost:27017/mecachamps
JWT_SECRET=mecachamps_super_secret_key_2024
PORT=5000
FRONTEND_URL=http://localhost:5173
```

> Si usás **MongoDB Atlas**, reemplazá MONGO_URI con tu connection string:
> `MONGO_URI=mongodb+srv://usuario:password@cluster.mongodb.net/mecachamps`

---

### PASO 3 — Cargar datos de ejemplo (opcional pero recomendado)

```bash
cd mecachamps/backend
npm run seed
```

Esto crea:
- 10 equipos en Primera División
- 10 equipos en Segunda División
- 15 jugadores por equipo (300 total)
- 3 noticias de ejemplo

---

### PASO 4 — Iniciar el Backend

```bash
cd mecachamps/backend
npm run dev
```

✅ Deberías ver:
```
✅ MongoDB connected
🚀 Server running on port 5000
```

---

### PASO 5 — Configurar el Frontend

```bash
cd mecachamps/frontend
npm install
```

---

### PASO 6 — Iniciar el Frontend

```bash
cd mecachamps/frontend
npm run dev
```

✅ Abrí en el navegador: **http://localhost:5173**

---

## 🔐 ACCESO ADMIN

| Usuario     | Contraseña |
|-------------|------------|
| Mecachamps  | abichuela  |

Ingresá en: http://localhost:5173/login

---

## 📋 FLUJO RECOMENDADO PARA EMPEZAR

1. **Login** como admin → http://localhost:5173/login
2. **Crear equipos** → Admin → Equipos → Nuevo Equipo (o usá el seed)
3. **Agregar jugadores** → Admin → Jugadores
4. **Generar fixture** → Admin → Fixture → Elegir fecha inicio → Generar
5. **Generar copa** → Admin → Copa → Generar Copa
6. **Cargar resultados** → Admin → Partidos → ⚽ CARGAR (en partidos pendientes)
7. **Publicar noticias** → Admin → Noticias

---

## 🌐 API REST — ENDPOINTS DISPONIBLES

### Auth
| Método | Ruta              | Descripción          |
|--------|-------------------|----------------------|
| POST   | /api/auth/login   | Login de administrador |
| GET    | /api/auth/verify  | Verificar token JWT  |

### Teams
| Método | Ruta              | Descripción          |
|--------|-------------------|----------------------|
| GET    | /api/teams        | Listar equipos       |
| GET    | /api/teams/:id    | Equipo + jugadores   |
| POST   | /api/teams        | Crear equipo (admin) |
| PUT    | /api/teams/:id    | Editar equipo (admin)|
| DELETE | /api/teams/:id    | Eliminar (admin)     |

### Players
| Método | Ruta              | Descripción          |
|--------|-------------------|----------------------|
| GET    | /api/players      | Listar jugadores     |
| GET    | /api/players/:id  | Detalle jugador      |
| POST   | /api/players      | Crear (admin)        |
| PUT    | /api/players/:id  | Editar (admin)       |
| DELETE | /api/players/:id  | Eliminar (admin)     |

### Matches
| Método | Ruta                          | Descripción               |
|--------|-------------------------------|---------------------------|
| GET    | /api/matches                  | Listar partidos (filtros) |
| GET    | /api/matches/standings/:div   | Tabla de posiciones       |
| GET    | /api/matches/:id              | Detalle partido           |
| POST   | /api/matches                  | Crear partido (admin)     |
| PUT    | /api/matches/:id              | Cargar resultado (admin)  |
| DELETE | /api/matches/:id              | Eliminar (admin)          |
| POST   | /api/matches/generate-fixture | Generar fixture (admin)   |

### Stats
| Método | Ruta                  | Descripción                           |
|--------|-----------------------|---------------------------------------|
| GET    | /api/stats/primera    | Estadísticas Primera División         |
| GET    | /api/stats/segunda    | Estadísticas Segunda División         |
| GET    | /api/stats/copa       | Estadísticas Copa                     |

### Copa
| Método | Ruta              | Descripción            |
|--------|-------------------|------------------------|
| GET    | /api/copa         | Estado del bracket     |
| POST   | /api/copa/generate| Generar copa (admin)   |
| PUT    | /api/copa/advance | Registrar ganador      |
| PUT    | /api/copa/set-teams| Asignar equipos a slot|

### News
| Método | Ruta          | Descripción         |
|--------|---------------|---------------------|
| GET    | /api/news     | Listar noticias     |
| GET    | /api/news/:id | Detalle noticia     |
| POST   | /api/news     | Crear (admin)       |
| PUT    | /api/news/:id | Editar (admin)      |
| DELETE | /api/news/:id | Eliminar (admin)    |

---

## 🔧 VARIABLES DE ENTORNO

### Backend (.env)
```
MONGO_URI=mongodb://localhost:27017/mecachamps
JWT_SECRET=mecachamps_super_secret_key_2024
PORT=5000
FRONTEND_URL=http://localhost:5173
```

### Frontend (opcional — .env)
```
VITE_API_URL=http://localhost:5000/api
```

> Por defecto usa el proxy de Vite (`/api` → `localhost:5000/api`), no hace falta configurar esto.

---

## 🛠️ COMANDOS ÚTILES

```bash
# Backend — desarrollo (con auto-reload)
cd backend && npm run dev

# Backend — producción
cd backend && npm start

# Backend — poblar DB con datos de ejemplo
cd backend && npm run seed

# Frontend — desarrollo
cd frontend && npm run dev

# Frontend — build para producción
cd frontend && npm run build
```

---

## 🎨 PALETA DE COLORES

| Color          | Hex       | Uso                    |
|----------------|-----------|------------------------|
| Negro profundo | `#050810` | Fondo principal        |
| Oscuro         | `#0a0f1e` | Cards y paneles        |
| Azul eléctrico | `#0ea5e9` | Acento principal       |
| Azul neón      | `#38bdf8` | Hover y detalles       |
| Azul (campeón) | `#3b82f6` | Posición 1°            |
| Verde          | `#22c55e` | Ascenso / ganador      |
| Rojo           | `#ef4444` | Descenso / roja        |
| Amarillo       | `#f59e0b` | Admin / tarjeta        |

---

## ⚠️ NOTAS IMPORTANTES

- Las **imágenes se guardan localmente** en `/backend/uploads/`. En producción, considerar Amazon S3 o Cloudinary.
- El **token JWT** dura 24 horas. Después hay que volver a loguearse.
- Las **estadísticas se recalculan automáticamente** al guardar un resultado de partido.
- La **tabla de posiciones** se calcula en tiempo real desde los partidos jugados.
- Para **producción**, cambiar `JWT_SECRET` a un valor seguro aleatorio.

---

## 📞 SOPORTE

¿Problemas? Revisá:
1. Que MongoDB esté corriendo (`mongod` o MongoDB Compass)
2. Que el backend esté en puerto 5000 y el frontend en 5173
3. Que la URI de MongoDB sea correcta en el `.env`
