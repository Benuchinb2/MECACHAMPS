const express = require('express');
const router = express.Router();
const Copa = require('../models/Copa');
const Match = require('../models/Match');
const Team = require('../models/Team');
const auth = require('../middleware/auth');

// GET /api/copa - Get copa bracket state
router.get('/', async (req, res) => {
  try {
    let copa = await Copa.findOne().sort({ createdAt: -1 })
      .populate('rounds.previo.homeTeam', 'name shield color')
      .populate('rounds.previo.awayTeam', 'name shield color')
      .populate('rounds.previo.winner', 'name shield color')
      .populate('rounds.octavos.homeTeam', 'name shield color')
      .populate('rounds.octavos.awayTeam', 'name shield color')
      .populate('rounds.octavos.winner', 'name shield color')
      .populate('rounds.cuartos.homeTeam', 'name shield color')
      .populate('rounds.cuartos.awayTeam', 'name shield color')
      .populate('rounds.cuartos.winner', 'name shield color')
      .populate('rounds.semifinal.homeTeam', 'name shield color')
      .populate('rounds.semifinal.awayTeam', 'name shield color')
      .populate('rounds.semifinal.winner', 'name shield color')
      .populate('rounds.final.homeTeam', 'name shield color')
      .populate('rounds.final.awayTeam', 'name shield color')
      .populate('rounds.final.winner', 'name shield color');

    if (!copa) {
      return res.json({ message: 'Copa no iniciada', copa: null });
    }

    // Get all copa matches
    const matches = await Match.find({ competition: 'copa' })
      .populate('homeTeam', 'name shield color')
      .populate('awayTeam', 'name shield color')
      .sort({ copaRound: 1, createdAt: 1 });

    res.json({ copa, matches });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/copa/generate - Generate copa bracket (admin only)
router.post('/generate', auth, async (req, res) => {
  try {
    const { startDate, finalIsSingleLeg } = req.body;

    // Get all 20 teams
    const allTeams = await Team.find({});
    if (allTeams.length < 4) {
      return res.status(400).json({ message: 'Se necesitan al menos 4 equipos para generar la copa.' });
    }

    // Delete previous copa
    await Copa.deleteMany({});
    await Match.deleteMany({ competition: 'copa' });

    // Shuffle teams
    const shuffled = [...allTeams].sort(() => Math.random() - 0.5);

    // With 20 teams:
    // - 8 teams play Previo (4 matches) -> 4 advance
    // - 12 seeded + 4 from previo = 16 in Octavos (8 matches) -> 8 advance
    // - Cuartos: 8 -> 4 (4 matches)
    // - Semifinal: 4 -> 2 (2 matches)
    // - Final: 2 -> 1 (1 match)

    const previoTeams = shuffled.slice(0, 8);   // 8 teams play previo
    const seededTeams = shuffled.slice(8, 20);   // 12 seeded to octavos

    const baseDate = startDate ? new Date(startDate) : new Date();
    const weekMs = 7 * 24 * 60 * 60 * 1000;

    const copaDoc = new Copa({
      season: new Date().getFullYear().toString(),
      finalIsSingleLeg: finalIsSingleLeg || false,
      rounds: {
        previo: [],
        octavos: [],
        cuartos: [],
        semifinal: [],
        final: [],
      }
    });

    // Generate PREVIO matches (4 matches, ida & vuelta)
    const previoMatches = [];
    for (let i = 0; i < previoTeams.length; i += 2) {
      const home = previoTeams[i];
      const away = previoTeams[i + 1];

      const idaMatch = await Match.create({
        homeTeam: home._id,
        awayTeam: away._id,
        competition: 'copa',
        round: 'Fase Previa',
        leg: 1,
        copaRound: 'previo',
        date: new Date(baseDate.getTime()),
        played: false,
      });

      const vueltaMatch = await Match.create({
        homeTeam: away._id,
        awayTeam: home._id,
        competition: 'copa',
        round: 'Fase Previa',
        leg: 2,
        copaRound: 'previo',
        date: new Date(baseDate.getTime() + weekMs),
        played: false,
      });

      copaDoc.rounds.previo.push({
        idaMatchId: idaMatch._id,
        vueltaMatchId: vueltaMatch._id,
        homeTeam: home._id,
        awayTeam: away._id,
        winner: null,
        position: previoMatches.length,
      });

      previoMatches.push({ home, away, idaMatch, vueltaMatch });
    }

    // Generate OCTAVOS matches (8 matches, ida & vuelta)
    // First 12 seeded + 4 TBD winners from previo
    const octavosDate = new Date(baseDate.getTime() + 3 * weekMs);

    // Pair seeded teams among themselves (6 matches from seeded)
    const seededPairs = [];
    for (let i = 0; i < seededTeams.length; i += 2) {
      seededPairs.push({ home: seededTeams[i], away: seededTeams[i + 1] });
    }

    for (let i = 0; i < seededPairs.length; i++) {
      const { home, away } = seededPairs[i];
      const idaMatch = await Match.create({
        homeTeam: home._id,
        awayTeam: away._id,
        competition: 'copa',
        round: 'Octavos de Final',
        leg: 1,
        copaRound: 'octavos',
        date: new Date(octavosDate.getTime()),
        played: false,
      });
      const vueltaMatch = await Match.create({
        homeTeam: away._id,
        awayTeam: home._id,
        competition: 'copa',
        round: 'Octavos de Final',
        leg: 2,
        copaRound: 'octavos',
        date: new Date(octavosDate.getTime() + weekMs),
        played: false,
      });
      copaDoc.rounds.octavos.push({
        idaMatchId: idaMatch._id,
        vueltaMatchId: vueltaMatch._id,
        homeTeam: home._id,
        awayTeam: away._id,
        winner: null,
        position: i,
      });
    }

    // 2 more octavos matches with TBD winners from previo
    for (let i = 0; i < 2; i++) {
      const idaMatch = await Match.create({
        homeTeam: null,
        awayTeam: null,
        competition: 'copa',
        round: 'Octavos de Final',
        leg: 1,
        copaRound: 'octavos',
        date: new Date(octavosDate.getTime()),
        played: false,
      });
      const vueltaMatch = await Match.create({
        homeTeam: null,
        awayTeam: null,
        competition: 'copa',
        round: 'Octavos de Final',
        leg: 2,
        copaRound: 'octavos',
        date: new Date(octavosDate.getTime() + weekMs),
        played: false,
      });
      copaDoc.rounds.octavos.push({
        idaMatchId: idaMatch._id,
        vueltaMatchId: vueltaMatch._id,
        homeTeam: null,
        awayTeam: null,
        winner: null,
        position: seededPairs.length + i,
      });
    }

    // Generate CUARTOS (4 matches, TBD)
    const cuartosDate = new Date(baseDate.getTime() + 6 * weekMs);
    for (let i = 0; i < 4; i++) {
      const idaMatch = await Match.create({
        homeTeam: null, awayTeam: null,
        competition: 'copa', round: 'Cuartos de Final',
        leg: 1, copaRound: 'cuartos',
        date: new Date(cuartosDate.getTime()), played: false,
      });
      const vueltaMatch = await Match.create({
        homeTeam: null, awayTeam: null,
        competition: 'copa', round: 'Cuartos de Final',
        leg: 2, copaRound: 'cuartos',
        date: new Date(cuartosDate.getTime() + weekMs), played: false,
      });
      copaDoc.rounds.cuartos.push({
        idaMatchId: idaMatch._id,
        vueltaMatchId: vueltaMatch._id,
        homeTeam: null, awayTeam: null, winner: null, position: i,
      });
    }

    // Generate SEMIFINAL (2 matches, TBD)
    const semifinalDate = new Date(baseDate.getTime() + 9 * weekMs);
    for (let i = 0; i < 2; i++) {
      const idaMatch = await Match.create({
        homeTeam: null, awayTeam: null,
        competition: 'copa', round: 'Semifinal',
        leg: 1, copaRound: 'semifinal',
        date: new Date(semifinalDate.getTime()), played: false,
      });
      const vueltaMatch = await Match.create({
        homeTeam: null, awayTeam: null,
        competition: 'copa', round: 'Semifinal',
        leg: 2, copaRound: 'semifinal',
        date: new Date(semifinalDate.getTime() + weekMs), played: false,
      });
      copaDoc.rounds.semifinal.push({
        idaMatchId: idaMatch._id,
        vueltaMatchId: vueltaMatch._id,
        homeTeam: null, awayTeam: null, winner: null, position: i,
      });
    }

    // Generate FINAL (1 match, configurable)
    const finalDate = new Date(baseDate.getTime() + 12 * weekMs);
    const finalIdaMatch = await Match.create({
      homeTeam: null, awayTeam: null,
      competition: 'copa', round: 'Final',
      leg: 1, copaRound: 'final',
      date: new Date(finalDate.getTime()), played: false,
    });

    copaDoc.rounds.final.push({
      idaMatchId: finalIdaMatch._id,
      vueltaMatchId: null,
      homeTeam: null, awayTeam: null, winner: null, position: 0,
    });

    if (!finalIsSingleLeg) {
      const finalVueltaMatch = await Match.create({
        homeTeam: null, awayTeam: null,
        competition: 'copa', round: 'Final',
        leg: 2, copaRound: 'final',
        date: new Date(finalDate.getTime() + weekMs), played: false,
      });
      copaDoc.rounds.final[0].vueltaMatchId = finalVueltaMatch._id;
    }

    await copaDoc.save();
    res.status(201).json({ message: 'Copa generada exitosamente', copa: copaDoc });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/copa/advance - Set winner of a copa match pair and advance (admin only)
router.put('/advance', auth, async (req, res) => {
  try {
    const { copaId, round, position, winnerId } = req.body;

    const copa = await Copa.findById(copaId);
    if (!copa) return res.status(404).json({ message: 'Copa no encontrada' });

    const roundData = copa.rounds[round];
    if (!roundData || !roundData[position]) {
      return res.status(400).json({ message: 'Ronda o posición inválida' });
    }

    roundData[position].winner = winnerId;
    await copa.save();

    res.json({ message: 'Ganador registrado', copa });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// PUT /api/copa/set-teams - Set teams for a copa slot (admin only)
router.put('/set-teams', auth, async (req, res) => {
  try {
    const { copaId, round, position, homeTeamId, awayTeamId } = req.body;

    const copa = await Copa.findById(copaId);
    if (!copa) return res.status(404).json({ message: 'Copa no encontrada' });

    const slot = copa.rounds[round][position];
    if (!slot) return res.status(400).json({ message: 'Slot inválido' });

    if (homeTeamId) slot.homeTeam = homeTeamId;
    if (awayTeamId) slot.awayTeam = awayTeamId;

    // Update corresponding matches
    if (slot.idaMatchId) {
      await Match.findByIdAndUpdate(slot.idaMatchId, {
        homeTeam: homeTeamId || null,
        awayTeam: awayTeamId || null,
      });
    }
    if (slot.vueltaMatchId) {
      await Match.findByIdAndUpdate(slot.vueltaMatchId, {
        homeTeam: awayTeamId || null,
        awayTeam: homeTeamId || null,
      });
    }

    await copa.save();
    res.json({ message: 'Equipos asignados', copa });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
