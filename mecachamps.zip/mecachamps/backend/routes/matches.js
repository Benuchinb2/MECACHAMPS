const express = require('express');
const router = express.Router();
const Match = require('../models/Match');
const Player = require('../models/Player');
const auth = require('../middleware/auth');

// Helper: recalculate all player stats from match events
async function recalculatePlayerStats() {
  // Reset all stats
  await Player.updateMany({}, {
    goalsLeague: 0, assistsLeague: 0, yellowCardsLeague: 0, redCardsLeague: 0,
    goalsCopa: 0, assistsCopa: 0, yellowCardsCopa: 0, redCardsCopa: 0,
  });

  // Get all played matches
  const matches = await Match.find({ played: true });

  for (const match of matches) {
    const isLeague = match.competition !== 'copa';
    for (const event of match.events) {
      const player = await Player.findById(event.player);
      if (!player) continue;

      if (isLeague) {
        if (event.type === 'goal') player.goalsLeague += 1;
        else if (event.type === 'assist') player.assistsLeague += 1;
        else if (event.type === 'yellow') player.yellowCardsLeague += 1;
        else if (event.type === 'red') player.redCardsLeague += 1;
      } else {
        if (event.type === 'goal') player.goalsCopa += 1;
        else if (event.type === 'assist') player.assistsCopa += 1;
        else if (event.type === 'yellow') player.yellowCardsCopa += 1;
        else if (event.type === 'red') player.redCardsCopa += 1;
      }
      await player.save();
    }
  }
}

// GET /api/matches - Get matches with filters
router.get('/', async (req, res) => {
  try {
    const { competition, round, played, team, copaRound } = req.query;
    const filter = {};
    if (competition) filter.competition = competition;
    if (round) filter.round = round;
    if (played !== undefined) filter.played = played === 'true';
    if (copaRound) filter.copaRound = copaRound;
    if (team) filter.$or = [{ homeTeam: team }, { awayTeam: team }];

    const matches = await Match.find(filter)
      .populate('homeTeam', 'name shield division color')
      .populate('awayTeam', 'name shield division color')
      .populate('events.player', 'name')
      .populate('events.team', 'name')
      .sort({ date: 1, createdAt: 1 });

    res.json(matches);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/matches/standings/:division - Get standings for a division
router.get('/standings/:division', async (req, res) => {
  try {
    const { division } = req.params;
    const Team = require('../models/Team');
    const teams = await Team.find({ division });

    const standings = await Promise.all(teams.map(async (team) => {
      const matches = await Match.find({
        competition: division,
        played: true,
        $or: [{ homeTeam: team._id }, { awayTeam: team._id }]
      });

      let pj = 0, pg = 0, pe = 0, pp = 0, gf = 0, gc = 0, pts = 0;

      for (const m of matches) {
        pj++;
        const isHome = m.homeTeam.toString() === team._id.toString();
        const myGoals = isHome ? m.homeScore : m.awayScore;
        const theirGoals = isHome ? m.awayScore : m.homeScore;
        gf += myGoals;
        gc += theirGoals;
        if (myGoals > theirGoals) { pg++; pts += 3; }
        else if (myGoals === theirGoals) { pe++; pts += 1; }
        else pp++;
      }

      return {
        team: { _id: team._id, name: team.name, shield: team.shield, color: team.color },
        pj, pg, pe, pp, gf, gc, df: gf - gc, pts
      };
    }));

    // Sort: pts desc, df desc, gf desc, name asc
    standings.sort((a, b) => {
      if (b.pts !== a.pts) return b.pts - a.pts;
      if (b.df !== a.df) return b.df - a.df;
      if (b.gf !== a.gf) return b.gf - a.gf;
      return a.team.name.localeCompare(b.team.name);
    });

    res.json(standings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/matches/:id
router.get('/:id', async (req, res) => {
  try {
    const match = await Match.findById(req.params.id)
      .populate('homeTeam', 'name shield color')
      .populate('awayTeam', 'name shield color')
      .populate('events.player', 'name photo')
      .populate('events.team', 'name');
    if (!match) return res.status(404).json({ message: 'Partido no encontrado' });
    res.json(match);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/matches - Create match (admin only)
router.post('/', auth, async (req, res) => {
  try {
    const { homeTeam, awayTeam, competition, round, leg, date, copaRound } = req.body;
    if (!homeTeam || !awayTeam || !competition) {
      return res.status(400).json({ message: 'homeTeam, awayTeam y competition son requeridos.' });
    }
    const match = new Match({
      homeTeam, awayTeam, competition, round: round || '',
      leg: leg || 1, date: date || null, copaRound: copaRound || null
    });
    await match.save();
    await match.populate('homeTeam', 'name shield color');
    await match.populate('awayTeam', 'name shield color');
    res.status(201).json(match);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/matches/:id - Update match result (admin only)
router.put('/:id', auth, async (req, res) => {
  try {
    const match = await Match.findById(req.params.id);
    if (!match) return res.status(404).json({ message: 'Partido no encontrado' });

    const { homeScore, awayScore, events, played, date, round } = req.body;

    if (homeScore !== undefined) match.homeScore = homeScore;
    if (awayScore !== undefined) match.awayScore = awayScore;
    if (events !== undefined) match.events = events;
    if (played !== undefined) match.played = played;
    if (date !== undefined) match.date = date;
    if (round !== undefined) match.round = round;

    // Auto-calculate scores from events if events provided
    if (events !== undefined) {
      const goalEvents = events.filter(e => e.type === 'goal');
      const homeGoals = goalEvents.filter(e => e.team?.toString() === match.homeTeam?.toString()).length;
      const awayGoals = goalEvents.filter(e => e.team?.toString() === match.awayTeam?.toString()).length;
      if (homeScore === undefined) match.homeScore = homeGoals;
      if (awayScore === undefined) match.awayScore = awayGoals;
    }

    await match.save();

    // Recalculate all player stats
    await recalculatePlayerStats();

    await match.populate('homeTeam', 'name shield color');
    await match.populate('awayTeam', 'name shield color');
    await match.populate('events.player', 'name');
    await match.populate('events.team', 'name');

    res.json(match);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/matches/:id (admin only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const match = await Match.findByIdAndDelete(req.params.id);
    if (!match) return res.status(404).json({ message: 'Partido no encontrado' });
    await recalculatePlayerStats();
    res.json({ message: 'Partido eliminado' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/matches/generate-fixture - Generate league fixture (admin only)
router.post('/generate-fixture', auth, async (req, res) => {
  try {
    const { division, startDate } = req.body;
    const Team = require('../models/Team');
    const teams = await Team.find({ division });

    if (teams.length < 2) {
      return res.status(400).json({ message: 'Se necesitan al menos 2 equipos.' });
    }

    // Delete existing unplayed matches for this division
    await Match.deleteMany({ competition: division, played: false });

    const teamIds = teams.map(t => t._id);
    const n = teamIds.length;
    const rounds = [];

    // Round-robin algorithm (circle method)
    const teamsForAlgo = [...teamIds];
    if (n % 2 !== 0) teamsForAlgo.push(null); // bye
    const numRounds = teamsForAlgo.length - 1;
    const half = teamsForAlgo.length / 2;

    for (let round = 0; round < numRounds; round++) {
      const roundMatches = [];
      for (let i = 0; i < half; i++) {
        const home = teamsForAlgo[i];
        const away = teamsForAlgo[teamsForAlgo.length - 1 - i];
        if (home !== null && away !== null) {
          roundMatches.push({ home, away });
        }
      }
      rounds.push(roundMatches);
      // Rotate (keep first fixed)
      teamsForAlgo.splice(1, 0, teamsForAlgo.pop());
    }

    // Calculate start date
    let currentDate = startDate ? new Date(startDate) : new Date();
    const matchDocs = [];

    // IDA rounds
    for (let r = 0; r < rounds.length; r++) {
      const roundNum = r + 1;
      for (const pair of rounds[r]) {
        matchDocs.push({
          homeTeam: pair.home,
          awayTeam: pair.away,
          competition: division,
          round: `Fecha ${roundNum}`,
          leg: 1,
          date: new Date(currentDate.getTime() + r * 7 * 24 * 60 * 60 * 1000),
          played: false,
          homeScore: 0,
          awayScore: 0,
          events: [],
        });
      }
    }

    // VUELTA rounds (reversed home/away)
    for (let r = 0; r < rounds.length; r++) {
      const roundNum = rounds.length + r + 1;
      for (const pair of rounds[r]) {
        matchDocs.push({
          homeTeam: pair.away,
          awayTeam: pair.home,
          competition: division,
          round: `Fecha ${roundNum}`,
          leg: 2,
          date: new Date(currentDate.getTime() + (rounds.length + r) * 7 * 24 * 60 * 60 * 1000),
          played: false,
          homeScore: 0,
          awayScore: 0,
          events: [],
        });
      }
    }

    await Match.insertMany(matchDocs);
    res.json({ message: `Fixture generado: ${matchDocs.length} partidos creados.`, count: matchDocs.length });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
