const express = require('express');
const router = express.Router();
const News = require('../models/News');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

// GET /api/news
router.get('/', async (req, res) => {
  try {
    const { limit = 20, skip = 0 } = req.query;
    const news = await News.find({})
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .skip(parseInt(skip));
    const total = await News.countDocuments();
    res.json({ news, total });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/news/:id
router.get('/:id', async (req, res) => {
  try {
    const news = await News.findById(req.params.id);
    if (!news) return res.status(404).json({ message: 'Noticia no encontrada' });
    res.json(news);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/news (admin only)
router.post('/', auth, upload.single('image'), async (req, res) => {
  try {
    const { title, content, excerpt, author } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Título y contenido requeridos' });

    const newsData = { title, content, excerpt: excerpt || content.substring(0, 150) + '...', author: author || 'La Meca Champs' };
    if (req.file) newsData.image = `/uploads/${req.file.filename}`;

    const news = new News(newsData);
    await news.save();
    res.status(201).json(news);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/news/:id (admin only)
router.put('/:id', auth, upload.single('image'), async (req, res) => {
  try {
    const news = await News.findById(req.params.id);
    if (!news) return res.status(404).json({ message: 'Noticia no encontrada' });

    const { title, content, excerpt, author } = req.body;
    if (title) news.title = title;
    if (content) news.content = content;
    if (excerpt) news.excerpt = excerpt;
    if (author) news.author = author;
    if (req.file) news.image = `/uploads/${req.file.filename}`;

    await news.save();
    res.json(news);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/news/:id (admin only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const news = await News.findByIdAndDelete(req.params.id);
    if (!news) return res.status(404).json({ message: 'Noticia no encontrada' });
    res.json({ message: 'Noticia eliminada' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
