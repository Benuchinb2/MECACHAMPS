const express = require('express');
const router = express.Router();
const Player = require('../models/Player');

// GET /api/stats/:competition - Get stats for a competition (primera, segunda, copa)
router.get('/:competition', async (req, res) => {
  try {
    const { competition } = req.params;
    const { limit = 20 } = req.query;

    let goalField, assistField, yellowField, redField;

    if (competition === 'copa') {
      goalField = 'goalsCopa';
      assistField = 'assistsCopa';
      yellowField = 'yellowCardsCopa';
      redField = 'redCardsCopa';
    } else {
      // For primera and segunda, use league stats but filter by team division
      goalField = 'goalsLeague';
      assistField = 'assistsLeague';
      yellowField = 'yellowCardsLeague';
      redField = 'redCardsLeague';
    }

    const allPlayers = await Player.find({}).populate('team', 'name shield division color');

    // Filter by division if not copa
    let players = allPlayers;
    if (competition !== 'copa') {
      players = allPlayers.filter(p => p.team && p.team.division === competition);
    }

    // Top scorers
    const scorers = [...players]
      .sort((a, b) => b[goalField] - a[goalField])
      .filter(p => p[goalField] > 0)
      .slice(0, parseInt(limit))
      .map(p => ({
        player: { _id: p._id, name: p.name, photo: p.photo, age: p.age, rating: p.rating },
        team: p.team,
        value: p[goalField]
      }));

    // Top assists
    const assisters = [...players]
      .sort((a, b) => b[assistField] - a[assistField])
      .filter(p => p[assistField] > 0)
      .slice(0, parseInt(limit))
      .map(p => ({
        player: { _id: p._id, name: p.name, photo: p.photo, age: p.age, rating: p.rating },
        team: p.team,
        value: p[assistField]
      }));

    // Yellow cards
    const yellows = [...players]
      .sort((a, b) => b[yellowField] - a[yellowField])
      .filter(p => p[yellowField] > 0)
      .slice(0, parseInt(limit))
      .map(p => ({
        player: { _id: p._id, name: p.name, photo: p.photo, age: p.age, rating: p.rating },
        team: p.team,
        value: p[yellowField]
      }));

    // Red cards
    const reds = [...players]
      .sort((a, b) => b[redField] - a[redField])
      .filter(p => p[redField] > 0)
      .slice(0, parseInt(limit))
      .map(p => ({
        player: { _id: p._id, name: p.name, photo: p.photo, age: p.age, rating: p.rating },
        team: p.team,
        value: p[redField]
      }));

    res.json({ scorers, assisters, yellows, reds, competition });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
