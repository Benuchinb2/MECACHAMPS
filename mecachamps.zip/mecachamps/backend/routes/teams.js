const express = require('express');
const router = express.Router();
const Team = require('../models/Team');
const Player = require('../models/Player');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

// GET /api/teams - Get all teams
router.get('/', async (req, res) => {
  try {
    const { division } = req.query;
    const filter = division ? { division } : {};
    const teams = await Team.find(filter).sort({ name: 1 });
    res.json(teams);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/teams/:id - Get single team with players
router.get('/:id', async (req, res) => {
  try {
    const team = await Team.findById(req.params.id);
    if (!team) return res.status(404).json({ message: 'Equipo no encontrado' });

    const players = await Player.find({ team: req.params.id }).sort({ name: 1 });
    res.json({ team, players });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/teams - Create team (admin only)
router.post('/', auth, upload.fields([
  { name: 'shield', maxCount: 1 },
  { name: 'jerseyHome', maxCount: 1 },
  { name: 'jerseyAway', maxCount: 1 },
  { name: 'jerseyBoth', maxCount: 1 },
]), async (req, res) => {
  try {
    const { name, division, president, color } = req.body;

    // Check division capacity (max 10 teams each)
    const count = await Team.countDocuments({ division });
    if (count >= 10) {
      return res.status(400).json({ message: `La ${division} ya tiene 10 equipos.` });
    }

    const teamData = {
      name, division, president: president || '', color: color || '#1e40af',
    };

    if (req.files?.shield) teamData.shield = `/uploads/${req.files.shield[0].filename}`;
    if (req.files?.jerseyHome) teamData.jerseyHome = `/uploads/${req.files.jerseyHome[0].filename}`;
    if (req.files?.jerseyAway) teamData.jerseyAway = `/uploads/${req.files.jerseyAway[0].filename}`;
    if (req.files?.jerseyBoth) teamData.jerseyBoth = `/uploads/${req.files.jerseyBoth[0].filename}`;

    const team = new Team(teamData);
    await team.save();
    res.status(201).json(team);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/teams/:id - Update team (admin only)
router.put('/:id', auth, upload.fields([
  { name: 'shield', maxCount: 1 },
  { name: 'jerseyHome', maxCount: 1 },
  { name: 'jerseyAway', maxCount: 1 },
  { name: 'jerseyBoth', maxCount: 1 },
]), async (req, res) => {
  try {
    const team = await Team.findById(req.params.id);
    if (!team) return res.status(404).json({ message: 'Equipo no encontrado' });

    const { name, division, president, color } = req.body;
    if (name) team.name = name;
    if (division) team.division = division;
    if (president !== undefined) team.president = president;
    if (color) team.color = color;

    if (req.files?.shield) team.shield = `/uploads/${req.files.shield[0].filename}`;
    if (req.files?.jerseyHome) team.jerseyHome = `/uploads/${req.files.jerseyHome[0].filename}`;
    if (req.files?.jerseyAway) team.jerseyAway = `/uploads/${req.files.jerseyAway[0].filename}`;
    if (req.files?.jerseyBoth) team.jerseyBoth = `/uploads/${req.files.jerseyBoth[0].filename}`;

    await team.save();
    res.json(team);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/teams/:id (admin only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const team = await Team.findByIdAndDelete(req.params.id);
    if (!team) return res.status(404).json({ message: 'Equipo no encontrado' });
    // Also delete players
    await Player.deleteMany({ team: req.params.id });
    res.json({ message: 'Equipo eliminado' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
