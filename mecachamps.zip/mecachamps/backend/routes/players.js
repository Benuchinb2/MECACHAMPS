const express = require('express');
const router = express.Router();
const Player = require('../models/Player');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

// GET /api/players - Get all players (optionally filtered by team)
router.get('/', async (req, res) => {
  try {
    const { team, division } = req.query;
    let filter = {};
    if (team) filter.team = team;

    let query = Player.find(filter).populate('team', 'name division shield color');

    if (division) {
      // Filter by team division after populate
      const players = await query;
      const filtered = players.filter(p => p.team && p.team.division === division);
      return res.json(filtered);
    }

    const players = await query.sort({ name: 1 });
    res.json(players);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/players/:id
router.get('/:id', async (req, res) => {
  try {
    const player = await Player.findById(req.params.id).populate('team', 'name division shield color');
    if (!player) return res.status(404).json({ message: 'Jugador no encontrado' });
    res.json(player);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/players (admin only)
router.post('/', auth, upload.single('photo'), async (req, res) => {
  try {
    const { name, age, rating, team, position, number } = req.body;
    if (!name || !team) return res.status(400).json({ message: 'Nombre y equipo requeridos' });

    const playerData = { name, age: age || 0, rating: rating || 75, team, position: position || 'Jugador', number: number || 0 };
    if (req.file) playerData.photo = `/uploads/${req.file.filename}`;

    const player = new Player(playerData);
    await player.save();
    await player.populate('team', 'name division shield color');
    res.status(201).json(player);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT /api/players/:id (admin only)
router.put('/:id', auth, upload.single('photo'), async (req, res) => {
  try {
    const player = await Player.findById(req.params.id);
    if (!player) return res.status(404).json({ message: 'Jugador no encontrado' });

    const { name, age, rating, team, position, number,
      goalsLeague, assistsLeague, yellowCardsLeague, redCardsLeague,
      goalsCopa, assistsCopa, yellowCardsCopa, redCardsCopa } = req.body;

    if (name) player.name = name;
    if (age !== undefined) player.age = age;
    if (rating !== undefined) player.rating = rating;
    if (team) player.team = team;
    if (position) player.position = position;
    if (number !== undefined) player.number = number;
    if (goalsLeague !== undefined) player.goalsLeague = goalsLeague;
    if (assistsLeague !== undefined) player.assistsLeague = assistsLeague;
    if (yellowCardsLeague !== undefined) player.yellowCardsLeague = yellowCardsLeague;
    if (redCardsLeague !== undefined) player.redCardsLeague = redCardsLeague;
    if (goalsCopa !== undefined) player.goalsCopa = goalsCopa;
    if (assistsCopa !== undefined) player.assistsCopa = assistsCopa;
    if (yellowCardsCopa !== undefined) player.yellowCardsCopa = yellowCardsCopa;
    if (redCardsCopa !== undefined) player.redCardsCopa = redCardsCopa;
    if (req.file) player.photo = `/uploads/${req.file.filename}`;

    await player.save();
    await player.populate('team', 'name division shield color');
    res.json(player);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE /api/players/:id (admin only)
router.delete('/:id', auth, async (req, res) => {
  try {
    const player = await Player.findByIdAndDelete(req.params.id);
    if (!player) return res.status(404).json({ message: 'Jugador no encontrado' });
    res.json({ message: 'Jugador eliminado' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
