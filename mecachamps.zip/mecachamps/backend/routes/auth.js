const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();

const ADMIN_USER = 'Mecachamps';
const ADMIN_PASS = 'abichuela';

// POST /api/auth/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ message: 'Usuario y contraseña requeridos.' });
  }

  if (username !== ADMIN_USER || password !== ADMIN_PASS) {
    return res.status(401).json({ message: 'Credenciales incorrectas.' });
  }

  const token = jwt.sign(
    { username, role: 'admin' },
    process.env.JWT_SECRET || 'mecachamps_secret',
    { expiresIn: '24h' }
  );

  res.json({
    token,
    user: { username, role: 'admin' },
    message: 'Login exitoso'
  });
});

// GET /api/auth/verify
router.get('/verify', require('../middleware/auth'), (req, res) => {
  res.json({ user: req.user, valid: true });
});

module.exports = router;
