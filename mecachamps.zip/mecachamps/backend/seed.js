require('dotenv').config();
const mongoose = require('mongoose');
const Team = require('./models/Team');
const Player = require('./models/Player');
const Match = require('./models/Match');
const News = require('./models/News');
const Copa = require('./models/Copa');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/mecachamps';

const firstaDivisionTeams = [
  { name: 'Los Titanes FC', president: 'Roberto García', color: '#1e40af' },
  { name: 'Águilas Doradas', president: 'Carlos Méndez', color: '#d97706' },
  { name: 'Dragones Negros', president: 'Miguel Torres', color: '#1f2937' },
  { name: 'Lobos del Norte', president: 'Pablo Ruiz', color: '#7c3aed' },
  { name: 'Piratas SC', president: 'Eduardo Vega', color: '#dc2626' },
  { name: 'Leones Reales', president: 'Fernando López', color: '#b45309' },
  { name: 'Sharks United', president: 'Alejandro Díaz', color: '#0284c7' },
  { name: 'Toros Bravos', president: 'Ricardo Molina', color: '#16a34a' },
  { name: 'Cóndores CF', president: 'Sebastián Romero', color: '#475569' },
  { name: 'Rayo Mecánico', president: 'Andrés Castillo', color: '#0891b2' },
];

const segundaDivisionTeams = [
  { name: 'Estrellas FC', president: 'Luis Herrera', color: '#6366f1' },
  { name: 'Vikingos SC', president: 'Mario Sánchez', color: '#065f46' },
  { name: 'Gladiadores CF', president: 'Nicolás Reyes', color: '#991b1b' },
  { name: 'Panteras Negras', president: 'Gustavo Morales', color: '#18181b' },
  { name: 'Halcones Azules', president: 'Diego Vargas', color: '#1d4ed8' },
  { name: 'Ciclones FC', president: 'Rodrigo Peña', color: '#0e7490' },
  { name: 'Meteoros SC', president: 'Hernán Silva', color: '#c2410c' },
  { name: 'Tifones CF', president: 'Matías Ortega', color: '#15803d' },
  { name: 'Volcanes FC', president: 'Emiliano Ramos', color: '#9f1239' },
  { name: 'Cometas SC', president: 'Facundo Cruz', color: '#6b21a8' },
];

const playerNames = [
  'Agustín Rodríguez', 'Bruno Fernández', 'Cristian López', 'Damián García',
  'Ezequiel Martínez', 'Federico Pérez', 'Gonzalo Sosa', 'Hernán Torres',
  'Ignacio Ruiz', 'Javier Molina', 'Kevin Díaz', 'Lucas Romero',
  'Manuel Vargas', 'Nicolás Herrera', 'Oscar Reyes', 'Pablo Morales',
  'Quirino Vega', 'Ramiro Silva', 'Santiago Cruz', 'Tomás Castillo',
];

const positions = ['Portero', 'Defensa', 'Mediocampista', 'Delantero'];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ MongoDB connected');

    // Clear database
    await Team.deleteMany({});
    await Player.deleteMany({});
    await Match.deleteMany({});
    await News.deleteMany({});
    await Copa.deleteMany({});
    console.log('🗑️  Database cleared');

    // Create Primera División teams
    const primeraTeams = [];
    for (const t of firstaDivisionTeams) {
      const team = await Team.create({ ...t, division: 'primera' });
      primeraTeams.push(team);
    }
    console.log(`✅ Created ${primeraTeams.length} Primera División teams`);

    // Create Segunda División teams
    const segundaTeams = [];
    for (const t of segundaDivisionTeams) {
      const team = await Team.create({ ...t, division: 'segunda' });
      segundaTeams.push(team);
    }
    console.log(`✅ Created ${segundaTeams.length} Segunda División teams`);

    // Create players for each team
    const allTeams = [...primeraTeams, ...segundaTeams];
    for (const team of allTeams) {
      for (let i = 0; i < 15; i++) {
        const nameIdx = (allTeams.indexOf(team) * 15 + i) % playerNames.length;
        await Player.create({
          name: `${playerNames[nameIdx]} ${i + 1}`,
          age: Math.floor(Math.random() * 15) + 18,
          rating: Math.floor(Math.random() * 30) + 65,
          team: team._id,
          position: positions[i % 4],
          number: i + 1,
        });
      }
    }
    console.log('✅ Players created');

    // Create some news
    const newsItems = [
      {
        title: 'Arranca La Meca Champs 2 - El torneo más esperado del año',
        content: 'Con la participación de 20 equipos distribuidos en dos divisiones, La Meca Champs 2 promete ser el torneo más emocionante de la historia. Los fanáticos ya están listos para vivir la experiencia.',
        excerpt: 'El torneo más esperado del año comienza con 20 equipos.',
        author: 'La Meca Champs',
      },
      {
        title: 'Los Titanes FC, grandes favoritos para la Primera División',
        content: 'Con un plantel de lujo y la experiencia de sus jugadores veteranos, Los Titanes FC se posicionan como los grandes favoritos para conquistar la Primera División de La Meca Champs 2.',
        excerpt: 'Los Titanes FC llegan como favoritos con un plantel de lujo.',
        author: 'La Meca Champs',
      },
      {
        title: 'La Copa: El sueño de los 20',
        content: 'Todos contra todos. En la Copa de La Meca Champs 2, los 20 equipos de ambas divisiones tendrán la oportunidad de conquistar el título de campeones de copa. Desde la fase previa hasta la gran final.',
        excerpt: 'Los 20 equipos compiten por el título de copa.',
        author: 'La Meca Champs',
      },
    ];

    for (const n of newsItems) {
      await News.create(n);
    }
    console.log('✅ News created');

    console.log('\n🏆 SEED COMPLETADO EXITOSAMENTE!');
    console.log('📊 Resumen:');
    console.log(`   - ${primeraTeams.length} equipos en Primera División`);
    console.log(`   - ${segundaTeams.length} equipos en Segunda División`);
    console.log(`   - ${allTeams.length * 15} jugadores creados`);
    console.log(`   - ${newsItems.length} noticias creadas`);
    console.log('\n💡 Próximos pasos:');
    console.log('   1. Ir al panel Admin → Fixture → Generar fixture de cada división');
    console.log('   2. Ir al panel Admin → Copa → Generar copa');
    console.log('   3. Cargar resultados cuando se jueguen los partidos');

    process.exit(0);
  } catch (err) {
    console.error('❌ Error en seed:', err);
    process.exit(1);
  }
}

seed();
