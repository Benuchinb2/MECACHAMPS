const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  type: { type: String, enum: ['goal', 'assist', 'yellow', 'red'], required: true },
  player: { type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true },
  team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  minute: { type: Number, default: 0 },
}, { _id: true });

const matchSchema = new mongoose.Schema({
  homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  homeScore: { type: Number, default: 0 },
  awayScore: { type: Number, default: 0 },
  competition: { type: String, enum: ['primera', 'segunda', 'copa'], required: true },
  round: { type: String, default: '' }, // "Fecha 1", "Octavos de Final", etc.
  leg: { type: Number, default: 1 }, // 1 = ida, 2 = vuelta
  played: { type: Boolean, default: false },
  date: { type: Date, default: null },
  events: [eventSchema],
  // Copa specific
  copaRound: { 
    type: String, 
    enum: ['previo', 'octavos', 'cuartos', 'semifinal', 'final', null],
    default: null 
  },
  coupledMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match', default: null }, // Links ida to vuelta
}, { timestamps: true });

// When a match is played, we need to know the winner for copa
matchSchema.methods.getWinner = function () {
  if (!this.played) return null;
  if (this.homeScore > this.awayScore) return this.homeTeam;
  if (this.awayScore > this.homeScore) return this.awayTeam;
  return 'draw';
};

module.exports = mongoose.model('Match', matchSchema);
