const mongoose = require('mongoose');

const playerSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  age: { type: Number, default: 0 },
  rating: { type: Number, default: 75, min: 0, max: 99 }, // media
  team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', required: true },
  photo: { type: String, default: null },
  position: { type: String, default: 'Jugador' },
  number: { type: Number, default: 0 },
  // Accumulated stats (updated when match results are saved)
  goalsLeague: { type: Number, default: 0 },
  assistsLeague: { type: Number, default: 0 },
  yellowCardsLeague: { type: Number, default: 0 },
  redCardsLeague: { type: Number, default: 0 },
  goalsCopa: { type: Number, default: 0 },
  assistsCopa: { type: Number, default: 0 },
  yellowCardsCopa: { type: Number, default: 0 },
  redCardsCopa: { type: Number, default: 0 },
}, { timestamps: true });

// Virtual for total goals
playerSchema.virtual('totalGoals').get(function () {
  return this.goalsLeague + this.goalsCopa;
});

module.exports = mongoose.model('Player', playerSchema);
