const mongoose = require('mongoose');

const teamSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  division: { type: String, enum: ['primera', 'segunda'], required: true },
  shield: { type: String, default: null },
  president: { type: String, default: '' },
  jerseyHome: { type: String, default: null },
  jerseyAway: { type: String, default: null },
  jerseyBoth: { type: String, default: null },
  color: { type: String, default: '#1e40af' }, // team color for UI
}, { timestamps: true });

module.exports = mongoose.model('Team', teamSchema);
