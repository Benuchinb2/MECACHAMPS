const mongoose = require('mongoose');

// Tracks the copa bracket state
const copaSchema = new mongoose.Schema({
  season: { type: String, default: '2024' },
  finalIsSingleLeg: { type: Boolean, default: false },
  rounds: {
    previo: [{
      matchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      idaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      vueltaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', default: null },
      position: Number, // bracket position
    }],
    octavos: [{
      idaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      vueltaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', default: null },
      position: Number,
    }],
    cuartos: [{
      idaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      vueltaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', default: null },
      position: Number,
    }],
    semifinal: [{
      idaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      vueltaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', default: null },
      position: Number,
    }],
    final: [{
      idaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      vueltaMatchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Match' },
      homeTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      awayTeam: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' },
      winner: { type: mongoose.Schema.Types.ObjectId, ref: 'Team', default: null },
      position: Number,
    }],
  },
}, { timestamps: true });

module.exports = mongoose.model('Copa', copaSchema);
