const mongoose = require('mongoose');

const newsSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  image: { type: String, default: null },
  content: { type: String, required: true },
  excerpt: { type: String, default: '' },
  author: { type: String, default: 'La Meca Champs' },
}, { timestamps: true });

module.exports = mongoose.model('News', newsSchema);
