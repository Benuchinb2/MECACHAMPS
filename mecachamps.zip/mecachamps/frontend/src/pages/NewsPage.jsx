import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';

export default function NewsPage() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const LIMIT = 9;

  const load = async (p = 0) => {
    setLoading(true);
    try {
      const res = await api.get(`/news?limit=${LIMIT}&skip=${p * LIMIT}`);
      setNews(res.data.news || []);
      setTotal(res.data.total || 0);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(page); }, [page]);

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <h1 className="meca-section-title mb-2">NOTICIAS</h1>
        <p className="text-slate-500 font-rajdhani mb-10">Todas las novedades de La Meca Champs 2</p>

        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
        ) : news.length === 0 ? (
          <div className="text-center py-20 text-slate-600">
            <div className="text-5xl mb-4">📡</div>
            <div className="font-rajdhani text-lg">Sin noticias por ahora.</div>
          </div>
        ) : (
          <>
            {/* Featured first */}
            {news[0] && (
              <Link to={`/noticias/${news[0]._id}`} className="meca-card group mb-6 block md:flex overflow-hidden">
                {news[0].image && (
                  <div className="md:w-1/2 h-56 md:h-auto overflow-hidden">
                    <img src={news[0].image} alt={news[0].title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  </div>
                )}
                <div className={`p-6 flex flex-col justify-center ${news[0].image ? 'md:w-1/2' : 'w-full'}`}>
                  <div className="text-xs font-orbitron text-meca-blue/60 mb-3 tracking-wider">
                    📡 DESTACADO · {new Date(news[0].createdAt).toLocaleDateString('es-AR', { day: '2-digit', month: 'long', year: 'numeric' })}
                  </div>
                  <h2 className="font-orbitron font-bold text-white text-xl md:text-2xl mb-3 group-hover:text-meca-blue transition-colors">
                    {news[0].title}
                  </h2>
                  <p className="font-exo text-slate-400 text-sm line-clamp-3">{news[0].excerpt}</p>
                  <div className="mt-4 text-meca-blue text-sm font-orbitron">LEER MÁS →</div>
                </div>
              </Link>
            )}

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {news.slice(1).map(n => (
                <Link key={n._id} to={`/noticias/${n._id}`} className="meca-card group block overflow-hidden">
                  {n.image && (
                    <div className="h-44 overflow-hidden">
                      <img src={n.image} alt={n.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    </div>
                  )}
                  <div className="p-4">
                    <div className="text-[10px] font-orbitron text-meca-blue/60 mb-2 tracking-wider">
                      {new Date(n.createdAt).toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </div>
                    <h3 className="font-rajdhani font-bold text-slate-200 group-hover:text-meca-blue transition-colors mb-2 line-clamp-2">
                      {n.title}
                    </h3>
                    <p className="text-xs font-exo text-slate-500 line-clamp-2">{n.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>

            {/* Pagination */}
            {total > LIMIT && (
              <div className="flex justify-center gap-3 mt-10">
                <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
                  className="meca-btn-secondary text-xs disabled:opacity-30">← ANTERIOR</button>
                <span className="font-orbitron text-xs text-slate-500 self-center">
                  {page + 1} / {Math.ceil(total / LIMIT)}
                </span>
                <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * LIMIT >= total}
                  className="meca-btn-secondary text-xs disabled:opacity-30">SIGUIENTE →</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
