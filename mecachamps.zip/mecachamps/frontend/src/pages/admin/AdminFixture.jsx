import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

export default function AdminFixture() {
  const [generating, setGenerating] = useState({ primera: false, segunda: false });
  const [stats, setStats] = useState({ primera: { total: 0, played: 0 }, segunda: { total: 0, played: 0 } });
  const [startDates, setStartDates] = useState({ primera: '', segunda: '' });
  const [loading, setLoading] = useState(true);

  const loadStats = async () => {
    try {
      const res = await api.get('/matches');
      const all = res.data;
      const p = all.filter(m => m.competition === 'primera');
      const s = all.filter(m => m.competition === 'segunda');
      setStats({
        primera: { total: p.length, played: p.filter(m => m.played).length },
        segunda: { total: s.length, played: s.filter(m => m.played).length },
      });
    } catch { toast.error('Error al cargar estadísticas'); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadStats(); }, []);

  const generateFixture = async (division) => {
    if (!confirm(`¿Generar fixture para ${division === 'primera' ? 'Primera' : 'Segunda'} División? Los partidos pendientes existentes serán eliminados.`)) return;
    setGenerating(g => ({ ...g, [division]: true }));
    try {
      const res = await api.post('/matches/generate-fixture', {
        division,
        startDate: startDates[division] || new Date().toISOString(),
      });
      toast.success(res.data.message);
      loadStats();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al generar fixture');
    } finally {
      setGenerating(g => ({ ...g, [division]: false }));
    }
  };

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-4xl mx-auto px-4 py-10">
        <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-4 inline-block">← ADMIN</Link>
        <h1 className="meca-section-title mb-2">GENERADOR DE FIXTURE</h1>
        <p className="text-slate-500 font-rajdhani mb-10">
          Genera automáticamente el fixture de ida y vuelta para cada división usando el algoritmo round-robin.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {[['primera', 'PRIMERA DIVISIÓN', '🏆'], ['segunda', 'SEGUNDA DIVISIÓN', '🥈']].map(([div, label, icon]) => (
            <div key={div} className="meca-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <span className="text-2xl">{icon}</span>
                <h2 className="font-orbitron font-bold text-white text-sm">{label}</h2>
              </div>

              {!loading && (
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="text-center p-3 bg-meca-darker rounded border border-meca-blue/10">
                    <div className="font-orbitron font-black text-2xl text-white">{stats[div].total}</div>
                    <div className="text-[10px] font-orbitron text-slate-600">PARTIDOS TOTAL</div>
                  </div>
                  <div className="text-center p-3 bg-meca-darker rounded border border-meca-blue/10">
                    <div className="font-orbitron font-black text-2xl text-green-400">{stats[div].played}</div>
                    <div className="text-[10px] font-orbitron text-slate-600">JUGADOS</div>
                  </div>
                </div>
              )}

              <div className="mb-4">
                <label className="meca-label">Fecha de inicio del torneo</label>
                <input
                  type="date"
                  className="meca-input"
                  value={startDates[div]}
                  onChange={e => setStartDates(d => ({ ...d, [div]: e.target.value }))}
                />
              </div>

              <button
                onClick={() => generateFixture(div)}
                disabled={generating[div]}
                className="w-full meca-btn-primary disabled:opacity-50"
              >
                {generating[div] ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                    </svg>
                    GENERANDO...
                  </span>
                ) : `⚡ GENERAR FIXTURE ${div === 'primera' ? '1ª' : '2ª'} DIV`}
              </button>

              <p className="text-[10px] font-exo text-slate-600 mt-3 text-center">
                Con 10 equipos: 90 partidos (45 ida + 45 vuelta)
              </p>
            </div>
          ))}
        </div>

        <div className="meca-card p-5 mt-6">
          <h3 className="font-orbitron text-xs text-meca-blue/70 tracking-widest mb-3">📋 INFORMACIÓN DEL ALGORITMO</h3>
          <ul className="space-y-1 text-sm font-rajdhani text-slate-400">
            <li>• Algoritmo <strong className="text-slate-200">Round Robin (método circular)</strong> — garantiza distribución equitativa</li>
            <li>• Se generan <strong className="text-slate-200">ida y vuelta</strong> — los roles local/visitante se invierten en la vuelta</li>
            <li>• Los partidos se distribuyen en <strong className="text-slate-200">fechas semanales</strong> a partir de la fecha de inicio</li>
            <li>• ⚠️ Al regenerar, los <strong className="text-red-400">partidos pendientes</strong> se eliminan. Los jugados se conservan.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
