import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

const EVENT_TYPES = [
  { value: 'goal', label: '⚽ Gol', color: 'text-white' },
  { value: 'assist', label: '🎯 Asistencia', color: 'text-meca-blue' },
  { value: 'yellow', label: '🟨 Amarilla', color: 'text-yellow-400' },
  { value: 'red', label: '🟥 Roja', color: 'text-red-400' },
];

function MatchResultModal({ match, teams, onClose, onSave }) {
  const [homeScore, setHomeScore] = useState(match.homeScore || 0);
  const [awayScore, setAwayScore] = useState(match.awayScore || 0);
  const [events, setEvents] = useState(match.events || []);
  const [newEvent, setNewEvent] = useState({ type: 'goal', player: '', team: '', minute: '' });
  const [homePlayers, setHomePlayers] = useState([]);
  const [awayPlayers, setAwayPlayers] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (match.homeTeam?._id) api.get(`/players?team=${match.homeTeam._id}`).then(r => setHomePlayers(r.data)).catch(() => {});
    if (match.awayTeam?._id) api.get(`/players?team=${match.awayTeam._id}`).then(r => setAwayPlayers(r.data)).catch(() => {});
  }, [match]);

  const allPlayers = [...homePlayers, ...awayPlayers];

  const addEvent = () => {
    if (!newEvent.player || !newEvent.type || !newEvent.team) return toast.error('Completá tipo, equipo y jugador');
    setEvents(ev => [...ev, { ...newEvent, minute: parseInt(newEvent.minute) || 0 }]);
    setNewEvent({ type: 'goal', player: '', team: '', minute: '' });

    // Auto-recalculate score from goals
    const updatedEvents = [...events, { ...newEvent, minute: parseInt(newEvent.minute) || 0 }];
    const homeGoals = updatedEvents.filter(e => e.type === 'goal' && e.team === match.homeTeam?._id).length;
    const awayGoals = updatedEvents.filter(e => e.type === 'goal' && e.team === match.awayTeam?._id).length;
    setHomeScore(homeGoals);
    setAwayScore(awayGoals);
  };

  const removeEvent = (idx) => {
    const updated = events.filter((_, i) => i !== idx);
    setEvents(updated);
    const homeGoals = updated.filter(e => e.type === 'goal' && e.team === match.homeTeam?._id).length;
    const awayGoals = updated.filter(e => e.type === 'goal' && e.team === match.awayTeam?._id).length;
    setHomeScore(homeGoals);
    setAwayScore(awayGoals);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await api.put(`/matches/${match._id}`, {
        homeScore, awayScore, events, played: true,
      });
      toast.success('Resultado guardado');
      onSave();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al guardar');
    } finally { setSaving(false); }
  };

  const getPlayerName = (playerId) => {
    const p = allPlayers.find(p => p._id === playerId);
    return p ? p.name : 'Jugador';
  };
  const getTeamName = (teamId) => {
    if (teamId === match.homeTeam?._id) return match.homeTeam?.name;
    if (teamId === match.awayTeam?._id) return match.awayTeam?.name;
    return 'Equipo';
  };

  return (
    <div className="fixed inset-0 modal-backdrop z-50 flex items-start justify-center p-4 overflow-y-auto">
      <div className="meca-card w-full max-w-2xl p-6 my-4 animate-fade-in">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-orbitron font-bold text-white text-sm">CARGAR RESULTADO</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white text-xl">✕</button>
        </div>

        {/* Match header */}
        <div className="meca-card p-4 mb-6 bg-meca-darker">
          <div className="text-[10px] font-orbitron text-slate-600 text-center mb-3">{match.round} · {match.competition.toUpperCase()}</div>
          <div className="grid grid-cols-3 items-center gap-4">
            <div className="text-right">
              <div className="font-rajdhani font-bold text-slate-200">{match.homeTeam?.name || 'Local'}</div>
            </div>
            <div className="flex items-center justify-center gap-3">
              <input type="number" value={homeScore} onChange={e => setHomeScore(parseInt(e.target.value) || 0)}
                className="w-12 text-center meca-input text-2xl font-orbitron font-black text-white" min="0" />
              <span className="text-meca-blue font-orbitron">-</span>
              <input type="number" value={awayScore} onChange={e => setAwayScore(parseInt(e.target.value) || 0)}
                className="w-12 text-center meca-input text-2xl font-orbitron font-black text-white" min="0" />
            </div>
            <div className="text-left">
              <div className="font-rajdhani font-bold text-slate-200">{match.awayTeam?.name || 'Visitante'}</div>
            </div>
          </div>
        </div>

        {/* Add event */}
        <div className="mb-4">
          <h3 className="font-orbitron text-xs text-meca-blue/70 tracking-widest mb-3">REGISTRAR EVENTO</h3>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <label className="meca-label">Tipo</label>
              <select className="meca-input" value={newEvent.type} onChange={e => setNewEvent(n => ({ ...n, type: e.target.value }))}>
                {EVENT_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
            </div>
            <div>
              <label className="meca-label">Minuto</label>
              <input type="number" className="meca-input" value={newEvent.minute}
                onChange={e => setNewEvent(n => ({ ...n, minute: e.target.value }))}
                placeholder="90'" min="1" max="120" />
            </div>
            <div>
              <label className="meca-label">Equipo</label>
              <select className="meca-input" value={newEvent.team} onChange={e => setNewEvent(n => ({ ...n, team: e.target.value, player: '' }))}>
                <option value="">Seleccionar...</option>
                <option value={match.homeTeam?._id}>{match.homeTeam?.name}</option>
                <option value={match.awayTeam?._id}>{match.awayTeam?.name}</option>
              </select>
            </div>
            <div>
              <label className="meca-label">Jugador</label>
              <select className="meca-input" value={newEvent.player} onChange={e => setNewEvent(n => ({ ...n, player: e.target.value }))}>
                <option value="">Seleccionar...</option>
                {(newEvent.team === match.homeTeam?._id ? homePlayers : newEvent.team === match.awayTeam?._id ? awayPlayers : [])
                  .map(p => <option key={p._id} value={p._id}>{p.name}</option>)}
              </select>
            </div>
          </div>
          <button onClick={addEvent} className="meca-btn-primary w-full">+ AGREGAR EVENTO</button>
        </div>

        {/* Events list */}
        {events.length > 0 && (
          <div className="mb-6">
            <h3 className="font-orbitron text-xs text-meca-blue/70 tracking-widest mb-3">EVENTOS ({events.length})</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {events.map((ev, i) => {
                const evType = EVENT_TYPES.find(t => t.value === ev.type);
                return (
                  <div key={i} className="flex items-center gap-3 px-3 py-2 bg-meca-darker rounded border border-meca-blue/10">
                    <span className="text-sm">{evType?.label.split(' ')[0]}</span>
                    <span className={`text-xs font-rajdhani font-semibold flex-1 ${evType?.color}`}>
                      {getPlayerName(ev.player)} · {getTeamName(ev.team)}
                    </span>
                    {ev.minute > 0 && <span className="text-xs font-orbitron text-slate-600">{ev.minute}'</span>}
                    <button onClick={() => removeEvent(i)} className="text-red-500 hover:text-red-300 text-sm">✕</button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <div className="flex gap-3">
          <button onClick={handleSave} disabled={saving} className="meca-btn-primary flex-1 disabled:opacity-50">
            {saving ? 'GUARDANDO...' : '✅ GUARDAR RESULTADO'}
          </button>
          <button onClick={onClose} className="meca-btn-secondary px-6">CANCELAR</button>
        </div>
      </div>
    </div>
  );
}

export default function AdminMatches() {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [filterComp, setFilterComp] = useState('primera');
  const [filterPlayed, setFilterPlayed] = useState('');
  const [filterRound, setFilterRound] = useState('');

  const load = async () => {
    try {
      const [m, t] = await Promise.all([api.get('/matches'), api.get('/teams')]);
      setMatches(m.data);
      setTeams(t.data);
    } catch { toast.error('Error al cargar'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const filtered = matches.filter(m => {
    const compOk = !filterComp || m.competition === filterComp;
    const playedOk = filterPlayed === '' || (filterPlayed === 'true' ? m.played : !m.played);
    const roundOk = !filterRound || m.round === filterRound;
    return compOk && playedOk && roundOk;
  });

  const rounds = [...new Set(matches.filter(m => m.competition === filterComp).map(m => m.round))].sort((a, b) => {
    return (parseInt(a.replace(/\D/g, '')) || 0) - (parseInt(b.replace(/\D/g, '')) || 0);
  });

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-2 inline-block">← ADMIN</Link>
            <h1 className="meca-section-title">GESTIÓN DE PARTIDOS</h1>
            <p className="text-slate-500 font-rajdhani text-sm">{matches.filter(m => m.played).length} jugados · {matches.filter(m => !m.played).length} pendientes</p>
          </div>
        </div>

        {selectedMatch && (
          <MatchResultModal
            match={selectedMatch}
            teams={teams}
            onClose={() => setSelectedMatch(null)}
            onSave={load}
          />
        )}

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <select className="meca-input max-w-[180px]" value={filterComp} onChange={e => { setFilterComp(e.target.value); setFilterRound(''); }}>
            <option value="primera">Primera División</option>
            <option value="segunda">Segunda División</option>
            <option value="copa">Copa</option>
          </select>
          <select className="meca-input max-w-[160px]" value={filterPlayed} onChange={e => setFilterPlayed(e.target.value)}>
            <option value="">Todos</option>
            <option value="false">Pendientes</option>
            <option value="true">Jugados</option>
          </select>
          <select className="meca-input max-w-[160px]" value={filterRound} onChange={e => setFilterRound(e.target.value)}>
            <option value="">Todas las fechas</option>
            {rounds.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>

        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
        ) : (
          <div className="space-y-2">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-slate-600 font-rajdhani">No hay partidos. Generá el fixture desde Admin → Fixture.</div>
            ) : filtered.map(m => (
              <div key={m._id} className="meca-card px-4 py-3 flex items-center gap-4">
                <div className="text-[10px] font-orbitron text-slate-600 w-20 shrink-0">{m.round}</div>

                <div className="flex-1 grid grid-cols-3 items-center gap-2">
                  <div className="text-right font-rajdhani font-semibold text-sm text-slate-200 truncate">
                    {m.homeTeam?.name || 'Por def.'}
                  </div>
                  <div className="text-center">
                    {m.played ? (
                      <span className="font-orbitron font-black text-white">
                        {m.homeScore} - {m.awayScore}
                      </span>
                    ) : (
                      <span className="font-orbitron text-xs text-meca-blue/40">VS</span>
                    )}
                  </div>
                  <div className="text-left font-rajdhani font-semibold text-sm text-slate-200 truncate">
                    {m.awayTeam?.name || 'Por def.'}
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {m.played ? (
                    <span className="text-[10px] font-orbitron text-green-400 border border-green-500/30 rounded px-2 py-0.5">✓ JUGADO</span>
                  ) : (
                    <span className="text-[10px] font-orbitron text-slate-600 border border-slate-700 rounded px-2 py-0.5">PENDIENTE</span>
                  )}
                  {(m.homeTeam && m.awayTeam) && (
                    <button
                      onClick={() => setSelectedMatch(m)}
                      className="meca-btn-secondary text-xs px-3 py-1.5">
                      {m.played ? '✏️ EDITAR' : '⚽ CARGAR'}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
