import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

const EMPTY_FORM = { name: '', age: '', rating: '75', team: '', position: 'Mediocampista', number: '' };
const POSITIONS = ['Portero', 'Defensa', 'Mediocampista', 'Delantero'];

export default function AdminPlayers() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [photo, setPhoto] = useState(null);
  const [saving, setSaving] = useState(false);
  const [filterTeam, setFilterTeam] = useState('');
  const [search, setSearch] = useState('');

  const load = async () => {
    try {
      const [p, t] = await Promise.all([api.get('/players'), api.get('/teams')]);
      setPlayers(p.data);
      setTeams(t.data);
    } catch { toast.error('Error al cargar'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setPhoto(null); setShowForm(true); };
  const openEdit = (p) => {
    setEditing(p._id);
    setForm({
      name: p.name, age: p.age, rating: p.rating, team: p.team?._id || '',
      position: p.position || 'Mediocampista', number: p.number || '',
    });
    setPhoto(null);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.team) return toast.error('Nombre y equipo son requeridos');
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (photo) fd.append('photo', photo);

      if (editing) {
        await api.put(`/players/${editing}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Jugador actualizado');
      } else {
        await api.post('/players', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Jugador creado');
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al guardar');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar este jugador?')) return;
    try {
      await api.delete(`/players/${id}`);
      toast.success('Jugador eliminado');
      load();
    } catch { toast.error('Error al eliminar'); }
  };

  const filtered = players.filter(p => {
    const matchTeam = !filterTeam || p.team?._id === filterTeam;
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase());
    return matchTeam && matchSearch;
  });

  const getRatingColor = (r) => r >= 85 ? '#f59e0b' : r >= 75 ? '#0ea5e9' : r >= 65 ? '#22c55e' : '#64748b';

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-2 inline-block">← ADMIN</Link>
            <h1 className="meca-section-title">GESTIÓN DE JUGADORES</h1>
            <p className="text-slate-500 font-rajdhani text-sm">{players.length} jugadores registrados</p>
          </div>
          <button onClick={openCreate} className="meca-btn-primary">+ NUEVO JUGADOR</button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <input className="meca-input max-w-xs" placeholder="🔍 Buscar jugador..." value={search}
            onChange={e => setSearch(e.target.value)} />
          <select className="meca-input max-w-xs" value={filterTeam} onChange={e => setFilterTeam(e.target.value)}>
            <option value="">Todos los equipos</option>
            {teams.map(t => <option key={t._id} value={t._id}>{t.name}</option>)}
          </select>
          {(filterTeam || search) && (
            <button onClick={() => { setFilterTeam(''); setSearch(''); }} className="meca-btn-secondary text-xs">✕ LIMPIAR</button>
          )}
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 modal-backdrop z-50 flex items-center justify-center p-4">
            <div className="meca-card w-full max-w-md p-6 max-h-[90vh] overflow-y-auto animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-orbitron font-bold text-white">{editing ? 'EDITAR JUGADOR' : 'NUEVO JUGADOR'}</h2>
                <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-white text-xl">✕</button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="meca-label">Nombre *</label>
                  <input className="meca-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nombre del jugador" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="meca-label">Edad</label>
                    <input type="number" className="meca-input" value={form.age} onChange={e => setForm(f => ({ ...f, age: e.target.value }))} placeholder="25" min="14" max="50" />
                  </div>
                  <div>
                    <label className="meca-label">Número</label>
                    <input type="number" className="meca-input" value={form.number} onChange={e => setForm(f => ({ ...f, number: e.target.value }))} placeholder="10" min="1" max="99" />
                  </div>
                </div>
                <div>
                  <label className="meca-label">Media (rating) — {form.rating}</label>
                  <input type="range" min="50" max="99" value={form.rating}
                    onChange={e => setForm(f => ({ ...f, rating: e.target.value }))}
                    className="w-full accent-meca-blue" />
                  <div className="flex justify-between text-[10px] font-orbitron mt-1">
                    <span style={{ color: getRatingColor(50) }}>50</span>
                    <span style={{ color: getRatingColor(parseInt(form.rating)) }} className="font-black">{form.rating}</span>
                    <span style={{ color: getRatingColor(99) }}>99</span>
                  </div>
                </div>
                <div>
                  <label className="meca-label">Posición</label>
                  <select className="meca-input" value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))}>
                    {POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="meca-label">Equipo *</label>
                  <select className="meca-input" value={form.team} onChange={e => setForm(f => ({ ...f, team: e.target.value }))}>
                    <option value="">Seleccionar equipo...</option>
                    {teams.map(t => <option key={t._id} value={t._id}>[{t.division === 'primera' ? '1ª' : '2ª'}] {t.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="meca-label">Foto del jugador</label>
                  <input type="file" accept="image/*" onChange={e => setPhoto(e.target.files[0])}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={saving} className="meca-btn-primary flex-1 disabled:opacity-50">
                    {saving ? 'GUARDANDO...' : editing ? 'ACTUALIZAR' : 'CREAR'}
                  </button>
                  <button type="button" onClick={() => setShowForm(false)} className="meca-btn-secondary px-6">CANCELAR</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Players list */}
        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
        ) : (
          <div className="space-y-2">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-slate-600 font-rajdhani">No se encontraron jugadores.</div>
            ) : filtered.map(p => (
              <div key={p._id} className="meca-card px-4 py-3 flex items-center gap-4">
                {p.photo ? (
                  <img src={p.photo} alt={p.name} className="w-10 h-10 rounded-full object-cover border border-meca-blue/20 shrink-0" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-meca-gray flex items-center justify-center font-bold text-sm text-meca-blue/50 shrink-0">
                    {p.name?.charAt(0)}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-rajdhani font-semibold text-slate-200">{p.name}</div>
                  <div className="text-xs font-exo text-slate-600">
                    {p.position} · {p.age}a · #{p.number} · {p.team?.name}
                  </div>
                </div>
                <div className="hidden sm:flex gap-4 text-center shrink-0">
                  <div>
                    <div className="font-orbitron font-black text-base" style={{ color: getRatingColor(p.rating) }}>{p.rating}</div>
                    <div className="text-[9px] font-orbitron text-slate-600">MEDIA</div>
                  </div>
                  <div>
                    <div className="font-orbitron font-black text-base text-white">{p.goalsLeague + p.goalsCopa}</div>
                    <div className="text-[9px] font-orbitron text-slate-600">GOL</div>
                  </div>
                  <div>
                    <div className="font-orbitron font-black text-base text-yellow-400">{p.yellowCardsLeague + p.yellowCardsCopa}</div>
                    <div className="text-[9px] font-orbitron text-slate-600">AM</div>
                  </div>
                  <div>
                    <div className="font-orbitron font-black text-base text-red-400">{p.redCardsLeague + p.redCardsCopa}</div>
                    <div className="text-[9px] font-orbitron text-slate-600">RJ</div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => openEdit(p)} className="text-xs font-orbitron text-meca-blue hover:text-blue-300 px-2 py-1 rounded border border-meca-blue/20 hover:bg-meca-blue/10 transition-all">✏️</button>
                  <button onClick={() => handleDelete(p._id)} className="text-xs font-orbitron text-red-400 hover:text-red-300 px-2 py-1 rounded border border-red-500/20 hover:bg-red-900/20 transition-all">🗑️</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
