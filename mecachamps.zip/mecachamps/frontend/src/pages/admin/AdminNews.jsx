import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

const EMPTY_FORM = { title: '', content: '', excerpt: '', author: 'La Meca Champs' };

export default function AdminNews() {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [image, setImage] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await api.get('/news?limit=50');
      setNews(res.data.news || []);
    } catch { toast.error('Error al cargar noticias'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setImage(null); setShowForm(true); };
  const openEdit = (n) => {
    setEditing(n._id);
    setForm({ title: n.title, content: n.content, excerpt: n.excerpt || '', author: n.author || 'La Meca Champs' });
    setImage(null);
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.content) return toast.error('Título y contenido son requeridos');
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (image) fd.append('image', image);

      if (editing) {
        await api.put(`/news/${editing}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Noticia actualizada');
      } else {
        await api.post('/news', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Noticia publicada');
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al guardar');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar esta noticia?')) return;
    try {
      await api.delete(`/news/${id}`);
      toast.success('Noticia eliminada');
      load();
    } catch { toast.error('Error al eliminar'); }
  };

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-2 inline-block">← ADMIN</Link>
            <h1 className="meca-section-title">GESTIÓN DE NOTICIAS</h1>
            <p className="text-slate-500 font-rajdhani text-sm">{news.length} noticias publicadas</p>
          </div>
          <button onClick={openCreate} className="meca-btn-primary">+ NUEVA NOTICIA</button>
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 modal-backdrop z-50 flex items-start justify-center p-4 overflow-y-auto">
            <div className="meca-card w-full max-w-2xl p-6 my-4 animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-orbitron font-bold text-white">{editing ? 'EDITAR NOTICIA' : 'NUEVA NOTICIA'}</h2>
                <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-white text-xl">✕</button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="meca-label">Título *</label>
                  <input className="meca-input" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                    placeholder="Título de la noticia" />
                </div>
                <div>
                  <label className="meca-label">Imagen destacada</label>
                  <input type="file" accept="image/*" onChange={e => setImage(e.target.files[0])}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div>
                  <label className="meca-label">Resumen (opcional)</label>
                  <input className="meca-input" value={form.excerpt} onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))}
                    placeholder="Breve descripción para la portada..." />
                </div>
                <div>
                  <label className="meca-label">Contenido *</label>
                  <textarea className="meca-input min-h-[200px] resize-y leading-relaxed"
                    value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                    placeholder="Escribí el contenido completo de la noticia..." />
                </div>
                <div>
                  <label className="meca-label">Autor</label>
                  <input className="meca-input" value={form.author} onChange={e => setForm(f => ({ ...f, author: e.target.value }))} />
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={saving} className="meca-btn-primary flex-1 disabled:opacity-50">
                    {saving ? 'PUBLICANDO...' : editing ? '✏️ ACTUALIZAR' : '📡 PUBLICAR'}
                  </button>
                  <button type="button" onClick={() => setShowForm(false)} className="meca-btn-secondary px-6">CANCELAR</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
        ) : news.length === 0 ? (
          <div className="text-center py-16 text-slate-600">
            <div className="text-5xl mb-4">📡</div>
            <div className="font-rajdhani text-lg">No hay noticias. ¡Creá la primera!</div>
          </div>
        ) : (
          <div className="space-y-3">
            {news.map(n => (
              <div key={n._id} className="meca-card p-4 flex items-center gap-4">
                {n.image && (
                  <img src={n.image} alt={n.title} className="w-16 h-12 object-cover rounded border border-meca-blue/10 shrink-0 hidden sm:block" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-rajdhani font-semibold text-slate-200 truncate">{n.title}</div>
                  <div className="text-xs font-exo text-slate-600 mt-0.5">
                    {new Date(n.createdAt).toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' })} · {n.author}
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Link to={`/noticias/${n._id}`} target="_blank"
                    className="text-xs font-orbitron text-slate-500 hover:text-slate-300 px-2 py-1 rounded border border-slate-700 hover:border-slate-500 transition-all">
                    👁️
                  </Link>
                  <button onClick={() => openEdit(n)}
                    className="text-xs font-orbitron text-meca-blue hover:text-blue-300 px-2 py-1 rounded border border-meca-blue/20 hover:bg-meca-blue/10 transition-all">
                    ✏️
                  </button>
                  <button onClick={() => handleDelete(n._id)}
                    className="text-xs font-orbitron text-red-400 hover:text-red-300 px-2 py-1 rounded border border-red-500/20 hover:bg-red-900/20 transition-all">
                    🗑️
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
