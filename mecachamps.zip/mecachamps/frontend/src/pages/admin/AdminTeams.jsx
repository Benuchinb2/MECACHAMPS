import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

const EMPTY_FORM = { name: '', division: 'primera', president: '', color: '#1e40af' };

export default function AdminTeams() {
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [files, setFiles] = useState({ shield: null, jerseyHome: null, jerseyAway: null, jerseyBoth: null });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const res = await api.get('/teams');
      setTeams(res.data);
    } catch { toast.error('Error al cargar equipos'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setFiles({}); setShowForm(true); };
  const openEdit = (team) => {
    setEditing(team._id);
    setForm({ name: team.name, division: team.division, president: team.president || '', color: team.color || '#1e40af' });
    setFiles({});
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.division) return toast.error('Nombre y división son requeridos');
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (files.shield) fd.append('shield', files.shield);
      if (files.jerseyHome) fd.append('jerseyHome', files.jerseyHome);
      if (files.jerseyAway) fd.append('jerseyAway', files.jerseyAway);
      if (files.jerseyBoth) fd.append('jerseyBoth', files.jerseyBoth);

      if (editing) {
        await api.put(`/teams/${editing}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Equipo actualizado');
      } else {
        await api.post('/teams', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Equipo creado');
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al guardar');
    } finally { setSaving(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('¿Eliminar este equipo y todos sus jugadores?')) return;
    try {
      await api.delete(`/teams/${id}`);
      toast.success('Equipo eliminado');
      load();
    } catch { toast.error('Error al eliminar'); }
  };

  const primera = teams.filter(t => t.division === 'primera');
  const segunda = teams.filter(t => t.division === 'segunda');

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-2 inline-block">← ADMIN</Link>
            <h1 className="meca-section-title">GESTIÓN DE EQUIPOS</h1>
          </div>
          <button onClick={openCreate} className="meca-btn-primary">+ NUEVO EQUIPO</button>
        </div>

        {/* Modal */}
        {showForm && (
          <div className="fixed inset-0 modal-backdrop z-50 flex items-center justify-center p-4">
            <div className="meca-card w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-orbitron font-bold text-white">{editing ? 'EDITAR EQUIPO' : 'NUEVO EQUIPO'}</h2>
                <button onClick={() => setShowForm(false)} className="text-slate-500 hover:text-white text-xl">✕</button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="meca-label">Nombre del equipo *</label>
                  <input className="meca-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Los Titanes FC" />
                </div>
                <div>
                  <label className="meca-label">División *</label>
                  <select className="meca-input" value={form.division} onChange={e => setForm(f => ({ ...f, division: e.target.value }))}>
                    <option value="primera">Primera División</option>
                    <option value="segunda">Segunda División</option>
                  </select>
                </div>
                <div>
                  <label className="meca-label">Presidente</label>
                  <input className="meca-input" value={form.president} onChange={e => setForm(f => ({ ...f, president: e.target.value }))} placeholder="Nombre del presidente" />
                </div>
                <div>
                  <label className="meca-label">Color del equipo</label>
                  <div className="flex gap-3 items-center">
                    <input type="color" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))}
                      className="w-10 h-10 rounded cursor-pointer border border-meca-blue/20 bg-transparent" />
                    <input className="meca-input flex-1" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} placeholder="#1e40af" />
                  </div>
                </div>
                <div>
                  <label className="meca-label">Escudo (imagen)</label>
                  <input type="file" accept="image/*" onChange={e => setFiles(f => ({ ...f, shield: e.target.files[0] }))}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div>
                  <label className="meca-label">Camiseta Titular</label>
                  <input type="file" accept="image/*" onChange={e => setFiles(f => ({ ...f, jerseyHome: e.target.files[0] }))}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div>
                  <label className="meca-label">Camiseta Suplente</label>
                  <input type="file" accept="image/*" onChange={e => setFiles(f => ({ ...f, jerseyAway: e.target.files[0] }))}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div>
                  <label className="meca-label">Ambas camisetas (una sola imagen)</label>
                  <input type="file" accept="image/*" onChange={e => setFiles(f => ({ ...f, jerseyBoth: e.target.files[0] }))}
                    className="meca-input text-slate-400 file:mr-3 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-orbitron file:bg-meca-blue/20 file:text-meca-blue cursor-pointer" />
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="submit" disabled={saving} className="meca-btn-primary flex-1 disabled:opacity-50">
                    {saving ? 'GUARDANDO...' : editing ? 'ACTUALIZAR' : 'CREAR EQUIPO'}
                  </button>
                  <button type="button" onClick={() => setShowForm(false)} className="meca-btn-secondary px-6">CANCELAR</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
        ) : (
          <>
            {[['primera', 'PRIMERA DIVISIÓN', primera], ['segunda', 'SEGUNDA DIVISIÓN', segunda]].map(([div, label, list]) => (
              <section key={div} className="mb-10">
                <h2 className="font-orbitron font-bold text-sm text-slate-400 mb-4 tracking-widest">
                  {label} <span className="text-meca-blue ml-2">{list.length}/10</span>
                </h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {list.map(team => (
                    <div key={team._id} className="meca-card p-4 flex items-center gap-4">
                      {team.shield ? (
                        <img src={team.shield} alt={team.name} className="w-12 h-12 object-contain shrink-0" />
                      ) : (
                        <div className="w-12 h-12 rounded-full flex items-center justify-center font-orbitron font-black text-sm shrink-0"
                          style={{ background: team.color + '22', color: team.color, border: `1px solid ${team.color}55` }}>
                          {team.name?.substring(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="font-rajdhani font-semibold text-slate-200 truncate">{team.name}</div>
                        {team.president && <div className="text-xs font-exo text-slate-600 truncate">{team.president}</div>}
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <button onClick={() => openEdit(team)}
                          className="text-xs font-orbitron text-meca-blue hover:text-blue-300 px-2 py-1 rounded border border-meca-blue/20 hover:bg-meca-blue/10 transition-all">
                          ✏️
                        </button>
                        <button onClick={() => handleDelete(team._id)}
                          className="text-xs font-orbitron text-red-400 hover:text-red-300 px-2 py-1 rounded border border-red-500/20 hover:bg-red-900/20 transition-all">
                          🗑️
                        </button>
                      </div>
                    </div>
                  ))}
                  {list.length === 0 && (
                    <div className="col-span-3 text-slate-600 font-rajdhani text-sm text-center py-6">
                      Sin equipos en esta división.
                    </div>
                  )}
                </div>
              </section>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
