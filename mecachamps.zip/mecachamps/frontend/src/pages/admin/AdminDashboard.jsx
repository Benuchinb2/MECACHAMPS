import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const adminSections = [
  { to: '/admin/equipos', label: 'EQUIPOS', icon: '⚙️', desc: 'Crear, editar equipos y subir escudos/camisetas' },
  { to: '/admin/jugadores', label: 'JUGADORES', icon: '👤', desc: 'Agregar y editar jugadores del plantel' },
  { to: '/admin/partidos', label: 'PARTIDOS', icon: '⚽', desc: 'Cargar resultados, goles, tarjetas y asistencias' },
  { to: '/admin/fixture', label: 'FIXTURE', icon: '📅', desc: 'Generar fixture de Primera y Segunda División' },
  { to: '/admin/copa', label: 'COPA', icon: '🏅', desc: 'Generar y gestionar el bracket de la copa' },
  { to: '/admin/noticias', label: 'NOTICIAS', icon: '📡', desc: 'Publicar y editar noticias del torneo' },
];

export default function AdminDashboard() {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <div className="text-xs font-orbitron text-yellow-400/70 tracking-widest mb-1">⚡ PANEL DE ADMINISTRACIÓN</div>
            <h1 className="meca-section-title">LA MECA CHAMPS 2</h1>
            <p className="text-slate-500 font-rajdhani text-sm mt-1">
              Bienvenido, <span className="text-yellow-400">{user?.username}</span>. Control total del torneo.
            </p>
          </div>
          <button onClick={logout}
            className="meca-btn-danger text-xs">🚪 SALIR</button>
        </div>

        {/* Quick stats links */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {adminSections.map(s => (
            <Link key={s.to} to={s.to}
              className="meca-card p-6 group block hover:border-yellow-500/30 transition-all">
              <div className="text-3xl mb-4">{s.icon}</div>
              <div className="font-orbitron font-bold text-yellow-400 group-hover:text-yellow-300 transition-colors mb-2 text-sm">
                {s.label}
              </div>
              <div className="text-xs font-rajdhani text-slate-500">{s.desc}</div>
            </Link>
          ))}
        </div>

        <div className="meca-divider mt-10" />

        <div className="flex flex-wrap gap-3 justify-center">
          <Link to="/" className="meca-btn-secondary text-xs">← VER SITIO PÚBLICO</Link>
          <Link to="/primera" className="meca-btn-secondary text-xs">Ver Primera División</Link>
          <Link to="/segunda" className="meca-btn-secondary text-xs">Ver Segunda División</Link>
          <Link to="/copa" className="meca-btn-secondary text-xs">Ver Copa</Link>
        </div>
      </div>
    </div>
  );
}
