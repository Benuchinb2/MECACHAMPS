import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../api';
import toast from 'react-hot-toast';

const ROUND_LABELS = {
  previo: 'FASE PREVIA', octavos: 'OCTAVOS', cuartos: 'CUARTOS',
  semifinal: 'SEMIFINAL', final: 'FINAL',
};

export default function AdminCopa() {
  const [copa, setCopa] = useState(null);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [startDate, setStartDate] = useState('');
  const [finalSingleLeg, setFinalSingleLeg] = useState(false);
  const [teams, setTeams] = useState([]);
  const [selectedRound, setSelectedRound] = useState('previo');
  const [advancingSlot, setAdvancingSlot] = useState(null);

  const load = async () => {
    try {
      const [copaRes, teamsRes] = await Promise.all([api.get('/copa'), api.get('/teams')]);
      setCopa(copaRes.data.copa);
      setMatches(copaRes.data.matches || []);
      setTeams(teamsRes.data);
    } catch { toast.error('Error al cargar copa'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleGenerate = async () => {
    if (!confirm('¿Generar la copa? Se eliminará la copa existente y sus partidos.')) return;
    setGenerating(true);
    try {
      const res = await api.post('/copa/generate', {
        startDate: startDate || new Date().toISOString(),
        finalIsSingleLeg: finalSingleLeg,
      });
      toast.success('Copa generada exitosamente');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error al generar copa');
    } finally { setGenerating(false); }
  };

  const handleSetWinner = async (round, position, winnerId) => {
    try {
      await api.put('/copa/advance', { copaId: copa._id, round, position, winnerId });
      toast.success('Ganador registrado');
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Error'); }
  };

  const handleSetTeams = async (round, position, homeTeamId, awayTeamId) => {
    try {
      await api.put('/copa/set-teams', { copaId: copa._id, round, position, homeTeamId, awayTeamId });
      toast.success('Equipos asignados');
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Error'); }
  };

  const roundMatches = matches.filter(m => m.copaRound === selectedRound);

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <Link to="/admin" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue mb-2 inline-block">← ADMIN</Link>
        <h1 className="meca-section-title mb-2">GESTIÓN DE COPA</h1>
        <p className="text-slate-500 font-rajdhani mb-8">Genera y administra el bracket eliminatorio</p>

        {/* Generate section */}
        <div className="meca-card p-6 mb-8">
          <h2 className="font-orbitron font-bold text-white text-sm mb-4">⚡ GENERAR COPA</h2>
          <div className="grid sm:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="meca-label">Fecha de inicio</label>
              <input type="date" className="meca-input" value={startDate} onChange={e => setStartDate(e.target.value)} />
            </div>
            <div className="flex items-center gap-3 pt-5">
              <input type="checkbox" id="finalSingle" checked={finalSingleLeg}
                onChange={e => setFinalSingleLeg(e.target.checked)}
                className="w-4 h-4 accent-meca-blue" />
              <label htmlFor="finalSingle" className="font-rajdhani text-sm text-slate-300 cursor-pointer">
                Final a partido único
              </label>
            </div>
            <div className="flex items-end">
              <button onClick={handleGenerate} disabled={generating}
                className="meca-btn-primary w-full disabled:opacity-50">
                {generating ? '⚙️ GENERANDO...' : '🏅 GENERAR COPA'}
              </button>
            </div>
          </div>
          <div className="text-[11px] font-exo text-slate-600">
            La copa incluye: Fase Previa (8 equipos) → Octavos (16) → Cuartos (8) → Semifinal (4) → Final (2)
          </div>
        </div>

        {copa && (
          <>
            <div className="flex gap-2 mb-6 flex-wrap">
              {Object.keys(ROUND_LABELS).map(r => (
                copa.rounds[r]?.length > 0 && (
                  <button key={r} onClick={() => setSelectedRound(r)}
                    className={`px-4 py-2 rounded text-xs font-orbitron tracking-wider transition-all
                      ${selectedRound === r
                        ? 'bg-meca-blue text-white'
                        : 'border border-meca-blue/20 text-slate-400 hover:border-meca-blue/50 hover:text-meca-blue'}`}>
                    {ROUND_LABELS[r]} ({copa.rounds[r].length})
                  </button>
                )
              ))}
            </div>

            {/* Round management */}
            <div className="space-y-4">
              {copa.rounds[selectedRound]?.map((slot, pos) => {
                const idaM = matches.find(m => m._id?.toString() === slot.idaMatchId?.toString() || m._id === slot.idaMatchId);
                const vueltaM = slot.vueltaMatchId ? matches.find(m => m._id?.toString() === slot.vueltaMatchId?.toString() || m._id === slot.vueltaMatchId) : null;

                return (
                  <div key={pos} className="meca-card p-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-orbitron text-meca-blue/70 tracking-wider">
                        {ROUND_LABELS[selectedRound]} · Llave {pos + 1}
                      </span>
                      {slot.winner && (
                        <span className="text-xs font-orbitron text-green-400 border border-green-500/30 rounded px-2 py-0.5">
                          ✓ GANADOR: {slot.winner.name || 'Definido'}
                        </span>
                      )}
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      {/* Set teams */}
                      <div>
                        <h4 className="meca-label mb-2">EQUIPOS</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[9px] font-orbitron text-slate-600 mb-1 block">LOCAL</label>
                            <select className="meca-input text-xs"
                              value={slot.homeTeam?._id || slot.homeTeam || ''}
                              onChange={e => handleSetTeams(selectedRound, pos, e.target.value, slot.awayTeam?._id || slot.awayTeam || null)}>
                              <option value="">Por definir</option>
                              {teams.map(t => <option key={t._id} value={t._id}>{t.name}</option>)}
                            </select>
                          </div>
                          <div>
                            <label className="text-[9px] font-orbitron text-slate-600 mb-1 block">VISITANTE</label>
                            <select className="meca-input text-xs"
                              value={slot.awayTeam?._id || slot.awayTeam || ''}
                              onChange={e => handleSetTeams(selectedRound, pos, slot.homeTeam?._id || slot.homeTeam || null, e.target.value)}>
                              <option value="">Por definir</option>
                              {teams.map(t => <option key={t._id} value={t._id}>{t.name}</option>)}
                            </select>
                          </div>
                        </div>
                      </div>

                      {/* Set winner */}
                      <div>
                        <h4 className="meca-label mb-2">REGISTRAR GANADOR</h4>
                        <div className="flex gap-2">
                          {[slot.homeTeam, slot.awayTeam].map((team, ti) => {
                            if (!team) return null;
                            const teamId = team._id || team;
                            const teamName = team.name || teams.find(t => t._id === teamId)?.name || 'Equipo';
                            const isWinner = slot.winner && (slot.winner._id === teamId || slot.winner === teamId);
                            return (
                              <button key={ti} onClick={() => handleSetWinner(selectedRound, pos, teamId)}
                                className={`flex-1 py-2 px-3 rounded text-xs font-orbitron transition-all
                                  ${isWinner
                                    ? 'bg-green-600/30 border border-green-500/50 text-green-400'
                                    : 'border border-meca-blue/20 text-slate-400 hover:border-meca-blue/50 hover:text-meca-blue'}`}>
                                {isWinner ? '✓ ' : ''}{teamName}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Match scores */}
                    <div className="mt-3 flex gap-4 text-xs font-orbitron">
                      {idaM && (
                        <span className={`${idaM.played ? 'text-slate-400' : 'text-slate-600'}`}>
                          IDA: {idaM.played ? `${idaM.homeScore}-${idaM.awayScore}` : 'Pendiente'}
                        </span>
                      )}
                      {vueltaM && (
                        <span className={`${vueltaM.played ? 'text-slate-400' : 'text-slate-600'}`}>
                          VUELTA: {vueltaM.played ? `${vueltaM.homeScore}-${vueltaM.awayScore}` : 'Pendiente'}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {!copa && !loading && (
          <div className="text-center py-16 text-slate-600">
            <div className="text-5xl mb-4">🏅</div>
            <div className="font-orbitron text-lg text-slate-500">Copa no generada aún</div>
            <div className="font-rajdhani text-sm mt-2">Usá el generador de arriba para crear la copa.</div>
          </div>
        )}
      </div>
    </div>
  );
}
