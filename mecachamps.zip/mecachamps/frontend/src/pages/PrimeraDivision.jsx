import React, { useEffect, useState } from 'react';
import api from '../api';
import StandingsTable from '../components/StandingsTable';
import MatchCard from '../components/MatchCard';

export default function PrimeraDivision() {
  const [tab, setTab] = useState('tabla');
  const [standings, setStandings] = useState([]);
  const [matches, setMatches] = useState([]);
  const [rounds, setRounds] = useState([]);
  const [selectedRound, setSelectedRound] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, m] = await Promise.all([
          api.get('/matches/standings/primera'),
          api.get('/matches?competition=primera'),
        ]);
        setStandings(s.data);
        const allMatches = m.data;
        setMatches(allMatches);
        const uniqueRounds = [...new Set(allMatches.map(m => m.round))].sort((a, b) => {
          const na = parseInt(a.replace(/\D/g, '')) || 0;
          const nb = parseInt(b.replace(/\D/g, '')) || 0;
          return na - nb;
        });
        setRounds(uniqueRounds);
        if (uniqueRounds.length) setSelectedRound(uniqueRounds[0]);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const filteredMatches = selectedRound
    ? matches.filter(m => m.round === selectedRound)
    : matches;

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded bg-blue-500/20 border border-blue-500/40 flex items-center justify-center">
              <span className="text-blue-400 text-sm font-orbitron font-bold">1</span>
            </div>
            <h1 className="meca-section-title">PRIMERA DIVISIÓN</h1>
          </div>
          <p className="text-slate-500 font-rajdhani ml-11">Liga todos contra todos · Ida y vuelta</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-6 border-b border-meca-blue/20 mb-6">
          {[['tabla', 'TABLA'], ['fixture', 'FIXTURE']].map(([val, label]) => (
            <button key={val} onClick={() => setTab(val)}
              className={`pb-3 text-sm font-orbitron font-semibold tracking-wider transition-all ${tab === val ? 'tab-active' : 'tab-inactive'}`}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'tabla' && (
          <div className="meca-card">
            <StandingsTable standings={standings} division="primera" loading={loading} />
          </div>
        )}

        {tab === 'fixture' && (
          <div>
            {rounds.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {rounds.map(r => (
                  <button key={r} onClick={() => setSelectedRound(r)}
                    className={`px-3 py-1.5 rounded text-xs font-orbitron font-semibold tracking-wider transition-all
                      ${selectedRound === r
                        ? 'bg-meca-blue text-white'
                        : 'border border-meca-blue/20 text-slate-400 hover:border-meca-blue/50 hover:text-meca-blue'}`}>
                    {r}
                  </button>
                ))}
              </div>
            )}
            {loading ? (
              <div className="text-center py-12 text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
            ) : filteredMatches.length === 0 ? (
              <div className="text-center py-12 text-slate-600 font-rajdhani">
                <div className="text-4xl mb-3">📅</div>
                <div>No hay partidos. Generá el fixture desde el panel Admin.</div>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {filteredMatches.map(m => <MatchCard key={m._id} match={m} />)}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
