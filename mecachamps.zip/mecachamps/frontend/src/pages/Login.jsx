import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const navigate = useNavigate();
  const { login, user } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  if (user) {
    navigate('/admin');
    return null;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!username || !password) return toast.error('Completá los campos');
    setLoading(true);
    try {
      await login(username, password);
      toast.success('Acceso concedido ⚡');
      navigate('/admin');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Credenciales incorrectas');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black bg-grid px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full border-2 border-meca-blue/40 bg-meca-blue/5 mb-4 animate-pulse-blue">
            <span className="font-orbitron font-black text-meca-blue text-xl">MC</span>
          </div>
          <h1 className="font-orbitron font-black text-white text-2xl mb-1">ACCESO ADMIN</h1>
          <p className="font-rajdhani text-slate-500 text-sm">La Meca Champs 2 · Panel de control</p>
        </div>

        {/* Form card */}
        <div className="meca-card p-8">
          <div className="mb-2 text-center">
            <span className="text-[10px] font-orbitron text-meca-blue/50 tracking-widest border border-meca-blue/20 rounded px-3 py-1">
              🔐 ZONA RESTRINGIDA
            </span>
          </div>

          <div className="meca-divider" />

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="meca-label">Usuario</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="meca-input"
                placeholder="Mecachamps"
                autoComplete="username"
              />
            </div>

            <div>
              <label className="meca-label">Contraseña</label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="meca-input pr-10"
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-meca-blue text-sm transition-colors"
                >
                  {showPass ? '🙈' : '👁️'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full meca-btn-primary py-3 mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                  </svg>
                  VERIFICANDO...
                </span>
              ) : '⚡ INGRESAR'}
            </button>
          </form>
        </div>

        <p className="text-center text-slate-700 font-orbitron text-[10px] mt-6 tracking-widest">
          LA MECA CHAMPS 2 · SISTEMA DE GESTIÓN
        </p>
      </div>
    </div>
  );
}
