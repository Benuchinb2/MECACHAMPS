import React, { useEffect, useState } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';

function StatList({ title, emoji, items, valueLabel, valueColor = 'text-white' }) {
  return (
    <div className="meca-card p-4">
      <h3 className="font-orbitron text-xs text-meca-blue/70 tracking-widest mb-4">{emoji} {title}</h3>
      {items.length === 0 ? (
        <div className="text-slate-600 text-sm font-rajdhani text-center py-6">Sin datos</div>
      ) : (
        <div>
          {items.map((item, i) => (
            <div key={item.player._id}
              className="flex items-center gap-3 py-2.5 border-b border-meca-blue/5 last:border-0 hover:bg-meca-blue/5 rounded transition-colors px-1">
              <span className="text-xs font-orbitron text-slate-600 w-5 text-center">{i + 1}</span>
              {item.player.photo ? (
                <img src={item.player.photo} alt={item.player.name}
                  className="w-8 h-8 rounded-full object-cover border border-meca-blue/20" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-meca-gray flex items-center justify-center text-xs font-bold text-meca-blue/50 shrink-0">
                  {item.player.name?.charAt(0)}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <div className="font-rajdhani font-semibold text-sm text-slate-200 truncate">{item.player.name}</div>
                {item.team && (
                  <Link to={`/equipos/${item.team._id}`}
                    className="text-[10px] font-orbitron text-slate-600 hover:text-meca-blue transition-colors truncate block">
                    {item.team.name}
                  </Link>
                )}
              </div>
              <div className={`font-orbitron font-black text-xl ${valueColor}`}>{item.value}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Estadisticas() {
  const [competition, setCompetition] = useState('primera');
  const [stats, setStats] = useState({ scorers: [], assisters: [], yellows: [], reds: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/stats/${competition}`)
      .then(res => setStats(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [competition]);

  const tabs = [
    { val: 'primera', label: '1ª DIVISIÓN' },
    { val: 'segunda', label: '2ª DIVISIÓN' },
    { val: 'copa', label: 'COPA' },
  ];

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-6xl mx-auto px-4 py-10">
        <h1 className="meca-section-title mb-2">ESTADÍSTICAS</h1>
        <p className="text-slate-500 font-rajdhani mb-8">Rankings individuales por competición</p>

        {/* Competition selector */}
        <div className="flex gap-2 mb-8 flex-wrap">
          {tabs.map(t => (
            <button key={t.val} onClick={() => setCompetition(t.val)}
              className={`px-5 py-2.5 rounded font-orbitron text-xs font-semibold tracking-wider transition-all
                ${competition === t.val
                  ? 'bg-meca-blue text-white shadow-lg shadow-meca-blue/20'
                  : 'border border-meca-blue/20 text-slate-400 hover:border-meca-blue/50 hover:text-meca-blue'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-20 text-meca-blue font-orbitron animate-pulse">CARGANDO ESTADÍSTICAS...</div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-6">
            <StatList title="GOLEADORES" emoji="⚽" items={stats.scorers} valueColor="text-white" />
            <StatList title="ASISTENCIAS" emoji="🎯" items={stats.assisters} valueColor="text-meca-blue" />
            <StatList title="TARJETAS AMARILLAS" emoji="🟨" items={stats.yellows} valueColor="text-yellow-400" />
            <StatList title="TARJETAS ROJAS" emoji="🟥" items={stats.reds} valueColor="text-red-400" />
          </div>
        )}
      </div>
    </div>
  );
}
