import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import MatchCard from '../components/MatchCard';

function StatBox({ value, label, icon, color = 'meca-blue' }) {
  return (
    <div className="meca-card p-5 flex flex-col items-center text-center">
      <div className="text-3xl mb-2">{icon}</div>
      <div className={`font-orbitron font-black text-3xl text-${color} mb-1`}>{value}</div>
      <div className="text-xs font-orbitron text-slate-500 tracking-wider">{label}</div>
    </div>
  );
}

export default function Home() {
  const [recentMatches, setRecentMatches] = useState([]);
  const [upcomingMatches, setUpcomingMatches] = useState([]);
  const [news, setNews] = useState([]);
  const [stats, setStats] = useState({ teams: 0, players: 0, goals: 0, matches: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [teamsRes, playersRes, matchesRes, newsRes] = await Promise.all([
          api.get('/teams'),
          api.get('/players'),
          api.get('/matches'),
          api.get('/news?limit=3'),
        ]);

        const allMatches = matchesRes.data;
        const played = allMatches.filter(m => m.played).slice(-6).reverse();
        const upcoming = allMatches.filter(m => !m.played).slice(0, 6);

        setRecentMatches(played);
        setUpcomingMatches(upcoming);
        setNews(newsRes.data.news || []);

        const totalGoals = allMatches
          .filter(m => m.played)
          .reduce((sum, m) => sum + (m.homeScore || 0) + (m.awayScore || 0), 0);

        setStats({
          teams: teamsRes.data.length,
          players: playersRes.data.length,
          goals: totalGoals,
          matches: allMatches.filter(m => m.played).length,
        });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-meca-blue/5 via-transparent to-meca-black" />
        <div className="absolute inset-0 bg-gradient-to-r from-meca-black via-transparent to-meca-black" />

        <div className="relative max-w-7xl mx-auto px-4 py-20 text-center">
          <div className="inline-block mb-4 px-3 py-1 rounded border border-meca-blue/30 bg-meca-blue/5">
            <span className="text-meca-blue font-orbitron text-xs tracking-widest animate-pulse">⚡ TEMPORADA 2024 EN CURSO</span>
          </div>

          <h1 className="font-orbitron font-black text-5xl md:text-7xl text-white mb-2 leading-tight">
            LA MECA
          </h1>
          <h1 className="font-orbitron font-black text-5xl md:text-7xl mb-6 leading-tight"
            style={{ color: '#0ea5e9', textShadow: '0 0 30px rgba(14,165,233,0.5), 0 0 60px rgba(14,165,233,0.2)' }}>
            CHAMPS 2
          </h1>
          <p className="font-rajdhani text-xl text-slate-400 mb-10 max-w-xl mx-auto">
            El torneo de fútbol más emocionante. 20 equipos. 2 divisiones. 1 copa.
          </p>

          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/primera" className="meca-btn-primary text-sm px-6 py-3">🏆 PRIMERA DIVISIÓN</Link>
            <Link to="/segunda" className="meca-btn-secondary text-sm px-6 py-3">🥈 SEGUNDA DIVISIÓN</Link>
            <Link to="/copa" className="meca-btn text-sm px-6 py-3 bg-yellow-900/30 border border-yellow-600/40 text-yellow-400 hover:bg-yellow-900/50">🏅 COPA</Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 pb-16">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <StatBox value={stats.teams} label="EQUIPOS" icon="⚙️" color="meca-blue" />
          <StatBox value={stats.players} label="JUGADORES" icon="👤" color="meca-blue" />
          <StatBox value={stats.goals} label="GOLES" icon="⚽" color="meca-blue" />
          <StatBox value={stats.matches} label="PARTIDOS JUGADOS" icon="📋" color="meca-blue" />
        </div>

        {/* Última jornada */}
        {recentMatches.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="meca-section-title">ÚLTIMOS RESULTADOS</h2>
                <p className="text-slate-500 font-rajdhani text-sm">Resultados recientes del torneo</p>
              </div>
              <Link to="/primera" className="text-meca-blue text-sm font-orbitron hover:text-blue-300 transition-colors">VER TODO →</Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentMatches.map(m => <MatchCard key={m._id} match={m} />)}
            </div>
          </section>
        )}

        {/* Próximos partidos */}
        {upcomingMatches.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="meca-section-title">PRÓXIMOS PARTIDOS</h2>
                <p className="text-slate-500 font-rajdhani text-sm">Fixture próximas fechas</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {upcomingMatches.map(m => <MatchCard key={m._id} match={m} />)}
            </div>
          </section>
        )}

        {/* Quick links */}
        <section className="mb-12">
          <h2 className="meca-section-title mb-6">ACCESOS RÁPIDOS</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              { to: '/primera', label: 'TABLA PRIMERA', icon: '🏆', desc: 'Posiciones y fixture' },
              { to: '/segunda', label: 'TABLA SEGUNDA', icon: '🥈', desc: 'Posiciones y fixture' },
              { to: '/copa', label: 'BRACKET COPA', icon: '🏅', desc: 'Eliminatorias copa' },
              { to: '/equipos', label: 'EQUIPOS', icon: '⚙️', desc: 'Planteles y escudos' },
              { to: '/estadisticas', label: 'ESTADÍSTICAS', icon: '📊', desc: 'Goleadores y más' },
              { to: '/noticias', label: 'NOTICIAS', icon: '📡', desc: 'Novedades del torneo' },
            ].map(item => (
              <Link key={item.to} to={item.to}
                className="meca-card p-5 group cursor-pointer block">
                <div className="text-3xl mb-3">{item.icon}</div>
                <div className="font-orbitron font-bold text-sm text-slate-200 group-hover:text-meca-blue transition-colors mb-1">
                  {item.label}
                </div>
                <div className="text-xs font-rajdhani text-slate-500">{item.desc}</div>
              </Link>
            ))}
          </div>
        </section>

        {/* News */}
        {news.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="meca-section-title">NOTICIAS</h2>
                <p className="text-slate-500 font-rajdhani text-sm">Últimas novedades</p>
              </div>
              <Link to="/noticias" className="text-meca-blue text-sm font-orbitron hover:text-blue-300 transition-colors">VER TODAS →</Link>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {news.map(n => (
                <Link key={n._id} to={`/noticias/${n._id}`} className="meca-card group block">
                  {n.image && (
                    <div className="h-40 overflow-hidden">
                      <img src={n.image} alt={n.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    </div>
                  )}
                  <div className="p-4">
                    <div className="text-[10px] font-orbitron text-meca-blue/60 mb-2 tracking-wider">
                      {new Date(n.createdAt).toLocaleDateString('es-AR', { day: '2-digit', month: 'short' })}
                    </div>
                    <h3 className="font-rajdhani font-bold text-slate-200 group-hover:text-meca-blue transition-colors mb-2 line-clamp-2">
                      {n.title}
                    </h3>
                    <p className="text-xs font-exo text-slate-500 line-clamp-2">{n.excerpt}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
