import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';
import PlayerCard from '../components/PlayerCard';

export default function TeamDetail() {
  const { id } = useParams();
  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('plantel');

  useEffect(() => {
    api.get(`/teams/${id}`)
      .then(res => { setTeam(res.data.team); setPlayers(res.data.players); })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
    </div>
  );

  if (!team) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-slate-500 font-rajdhani">Equipo no encontrado</div>
    </div>
  );

  const divisionLabel = team.division === 'primera' ? 'Primera División' : 'Segunda División';

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      {/* Hero */}
      <div className="border-b border-meca-blue/10"
        style={{ background: `linear-gradient(135deg, ${team.color}11 0%, #050810 60%)` }}>
        <div className="max-w-6xl mx-auto px-4 py-10">
          <Link to="/equipos" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue transition-colors mb-6 inline-block">
            ← EQUIPOS
          </Link>
          <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
            {/* Shield */}
            <div className="shrink-0">
              {team.shield ? (
                <img src={team.shield} alt={team.name} className="w-32 h-32 object-contain drop-shadow-2xl" />
              ) : (
                <div className="w-32 h-32 rounded-full flex items-center justify-center font-orbitron font-black text-4xl"
                  style={{ background: team.color + '22', color: team.color, border: `3px solid ${team.color}55` }}>
                  {team.name?.substring(0, 2).toUpperCase()}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 text-center md:text-left">
              <div className="text-xs font-orbitron tracking-widest mb-2" style={{ color: team.color }}>
                ⚙️ {divisionLabel.toUpperCase()}
              </div>
              <h1 className="font-orbitron font-black text-4xl text-white mb-3">{team.name}</h1>
              {team.president && (
                <div className="flex items-center gap-2 justify-center md:justify-start mb-4">
                  <span className="text-slate-600 font-rajdhani text-sm">Presidente:</span>
                  <span className="font-rajdhani font-semibold text-slate-200">{team.president}</span>
                </div>
              )}
              <div className="flex gap-4 justify-center md:justify-start text-center">
                <div>
                  <div className="font-orbitron font-black text-2xl text-white">{players.length}</div>
                  <div className="text-[10px] font-orbitron text-slate-600">JUGADORES</div>
                </div>
                <div>
                  <div className="font-orbitron font-black text-2xl text-white">
                    {players.reduce((s, p) => s + p.goalsLeague + p.goalsCopa, 0)}
                  </div>
                  <div className="text-[10px] font-orbitron text-slate-600">GOLES</div>
                </div>
                <div>
                  <div className="font-orbitron font-black text-2xl text-white">
                    {Math.round(players.reduce((s, p) => s + p.rating, 0) / (players.length || 1))}
                  </div>
                  <div className="text-[10px] font-orbitron text-slate-600">MEDIA</div>
                </div>
              </div>
            </div>

            {/* Jerseys */}
            <div className="shrink-0 flex gap-3">
              {team.jerseyBoth && (
                <div className="text-center">
                  <img src={team.jerseyBoth} alt="Camisetas" className="h-24 object-contain" />
                  <div className="text-[10px] font-orbitron text-slate-600 mt-1">CAMISETAS</div>
                </div>
              )}
              {!team.jerseyBoth && team.jerseyHome && (
                <div className="text-center">
                  <img src={team.jerseyHome} alt="Titular" className="h-24 object-contain" />
                  <div className="text-[10px] font-orbitron text-slate-600 mt-1">TITULAR</div>
                </div>
              )}
              {!team.jerseyBoth && team.jerseyAway && (
                <div className="text-center">
                  <img src={team.jerseyAway} alt="Suplente" className="h-24 object-contain" />
                  <div className="text-[10px] font-orbitron text-slate-600 mt-1">SUPLENTE</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-6 border-b border-meca-blue/20 mb-8">
          {[['plantel', 'PLANTEL'], ['stats', 'ESTADÍSTICAS']].map(([val, label]) => (
            <button key={val} onClick={() => setTab(val)}
              className={`pb-3 text-sm font-orbitron font-semibold tracking-wider transition-all ${tab === val ? 'tab-active' : 'tab-inactive'}`}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'plantel' && (
          players.length === 0 ? (
            <div className="text-center py-12 text-slate-600 font-rajdhani">No hay jugadores registrados para este equipo.</div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {players.map(p => <PlayerCard key={p._id} player={p} showTeam={false} />)}
            </div>
          )
        )}

        {tab === 'stats' && (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Top scorers of team */}
            {['goalsLeague', 'assistsLeague', 'yellowCardsLeague', 'redCardsLeague'].map((field, i) => {
              const labels = ['⚽ GOLES', '🎯 ASISTENCIAS', '🟨 AMARILLAS', '🟥 ROJAS'];
              const colors = ['text-white', 'text-meca-blue', 'text-yellow-400', 'text-red-400'];
              const sorted = [...players].sort((a, b) => (b[field] + (b[field.replace('League', 'Copa')] || 0)) - (a[field] + (a[field.replace('League', 'Copa')] || 0)))
                .filter(p => (p[field] + (p[field.replace('League', 'Copa')] || 0)) > 0).slice(0, 5);
              return (
                <div key={field} className="meca-card p-4">
                  <h3 className="font-orbitron text-xs text-meca-blue/70 tracking-widest mb-4">{labels[i]}</h3>
                  {sorted.length === 0 ? (
                    <div className="text-slate-600 text-sm font-rajdhani text-center py-4">Sin datos</div>
                  ) : sorted.map((p, idx) => {
                    const total = (p[field] || 0) + (p[field.replace('League', 'Copa')] || 0);
                    return (
                      <div key={p._id} className="flex items-center gap-3 py-2 border-b border-meca-blue/5 last:border-0">
                        <span className="text-xs font-orbitron text-slate-600 w-4">{idx + 1}</span>
                        {p.photo ? (
                          <img src={p.photo} alt={p.name} className="w-7 h-7 rounded-full object-cover" />
                        ) : (
                          <div className="w-7 h-7 rounded-full bg-meca-gray flex items-center justify-center text-xs font-bold text-meca-blue/50">
                            {p.name?.charAt(0)}
                          </div>
                        )}
                        <span className="flex-1 font-rajdhani font-semibold text-sm text-slate-200">{p.name}</span>
                        <span className={`font-orbitron font-black text-lg ${colors[i]}`}>{total}</span>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
