import React, { useEffect, useState } from 'react';
import api from '../api';
import MatchCard from '../components/MatchCard';

const ROUND_LABELS = {
  previo: 'FASE PREVIA',
  octavos: 'OCTAVOS DE FINAL',
  cuartos: 'CUARTOS DE FINAL',
  semifinal: 'SEMIFINAL',
  final: 'FINAL',
};

function BracketSlot({ slot, matches = [] }) {
  const home = slot?.homeTeam;
  const away = slot?.awayTeam;
  const winner = slot?.winner;

  const idaMatch = matches.find(m => m._id === slot?.idaMatchId || m._id?.toString() === slot?.idaMatchId?.toString());
  const vueltaMatch = matches.find(m => m._id === slot?.vueltaMatchId || m._id?.toString() === slot?.vueltaMatchId?.toString());

  const TeamRow = ({ team, isWinner }) => (
    <div className={`flex items-center gap-2 px-3 py-2 border-b border-meca-blue/10 last:border-0
      ${isWinner ? 'bg-meca-blue/10' : ''}`}>
      {team ? (
        <>
          {team.shield ? (
            <img src={team.shield} alt={team.name} className="w-5 h-5 object-contain" />
          ) : (
            <div className="w-5 h-5 rounded-full text-[8px] font-bold flex items-center justify-center shrink-0"
              style={{ background: (team.color || '#1e40af') + '33', color: team.color || '#1e40af' }}>
              {team.name?.substring(0, 2).toUpperCase()}
            </div>
          )}
          <span className={`font-rajdhani text-xs font-semibold flex-1 truncate
            ${isWinner ? 'text-meca-blue' : 'text-slate-300'}`}>
            {team.name}
          </span>
          {isWinner && <span className="text-meca-blue text-xs">✓</span>}
        </>
      ) : (
        <span className="text-slate-600 text-xs font-rajdhani">Por definir</span>
      )}
    </div>
  );

  return (
    <div className="meca-card min-w-[200px] max-w-[220px] overflow-hidden">
      <TeamRow team={home} isWinner={winner && home && winner._id === home._id} />
      <TeamRow team={away} isWinner={winner && away && winner._id === away._id} />
      {/* Scores */}
      {(idaMatch?.played || vueltaMatch?.played) && (
        <div className="px-3 py-1.5 bg-meca-darker/50 flex gap-3 text-[10px] font-orbitron text-slate-600">
          {idaMatch?.played && (
            <span>IDA: <span className="text-slate-400">{idaMatch.homeScore}-{idaMatch.awayScore}</span></span>
          )}
          {vueltaMatch?.played && (
            <span>VTA: <span className="text-slate-400">{vueltaMatch.homeScore}-{vueltaMatch.awayScore}</span></span>
          )}
        </div>
      )}
    </div>
  );
}

function BracketRound({ roundKey, slots, matches }) {
  if (!slots || slots.length === 0) return null;
  return (
    <div className="flex flex-col gap-4 items-center">
      <div className="text-[10px] font-orbitron text-meca-blue/70 tracking-widest mb-2 text-center">
        {ROUND_LABELS[roundKey]}
      </div>
      <div className="flex flex-col gap-6">
        {slots.map((slot, i) => (
          <BracketSlot key={i} slot={slot} matches={matches} />
        ))}
      </div>
    </div>
  );
}

export default function Copa() {
  const [copa, setCopa] = useState(null);
  const [matches, setMatches] = useState([]);
  const [tab, setTab] = useState('bracket');
  const [loading, setLoading] = useState(true);
  const [selectedRound, setSelectedRound] = useState('previo');

  useEffect(() => {
    const load = async () => {
      try {
        const res = await api.get('/copa');
        setCopa(res.data.copa);
        setMatches(res.data.matches || []);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const roundMatches = matches.filter(m => m.copaRound === selectedRound);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-meca-blue font-orbitron animate-pulse">CARGANDO COPA...</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl">🏅</span>
            <h1 className="meca-section-title">COPA LA MECA CHAMPS</h1>
          </div>
          <p className="text-slate-500 font-rajdhani ml-10">20 equipos · Eliminación directa · Ida y vuelta</p>
        </div>

        <div className="flex gap-6 border-b border-meca-blue/20 mb-6">
          {[['bracket', 'BRACKET'], ['partidos', 'PARTIDOS']].map(([val, label]) => (
            <button key={val} onClick={() => setTab(val)}
              className={`pb-3 text-sm font-orbitron font-semibold tracking-wider transition-all ${tab === val ? 'tab-active' : 'tab-inactive'}`}>
              {label}
            </button>
          ))}
        </div>

        {!copa ? (
          <div className="text-center py-20 text-slate-600">
            <div className="text-5xl mb-4">🏅</div>
            <div className="font-orbitron text-lg text-slate-500 mb-2">Copa no iniciada</div>
            <div className="font-rajdhani text-sm">Un administrador debe generar la copa desde el panel Admin.</div>
          </div>
        ) : (
          <>
            {tab === 'bracket' && (
              <div>
                <div className="overflow-x-auto pb-8">
                  <div className="flex gap-8 min-w-max px-4">
                    {['previo', 'octavos', 'cuartos', 'semifinal', 'final'].map(round => (
                      copa.rounds[round]?.length > 0 && (
                        <BracketRound
                          key={round}
                          roundKey={round}
                          slots={copa.rounds[round]}
                          matches={matches}
                        />
                      )
                    ))}
                  </div>
                </div>

                {/* Winner */}
                {copa.rounds?.final?.[0]?.winner && (
                  <div className="mt-8 text-center">
                    <div className="inline-block px-8 py-6 meca-card border-yellow-500/40 bg-yellow-900/10">
                      <div className="text-4xl mb-2">🏆</div>
                      <div className="font-orbitron font-black text-yellow-400 text-xl mb-1">CAMPEÓN DE COPA</div>
                      <div className="font-rajdhani text-2xl text-white font-bold">
                        {copa.rounds.final[0].winner.name}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === 'partidos' && (
              <div>
                <div className="flex flex-wrap gap-2 mb-6">
                  {Object.keys(ROUND_LABELS).map(r => (
                    copa.rounds[r]?.length > 0 && (
                      <button key={r} onClick={() => setSelectedRound(r)}
                        className={`px-3 py-1.5 rounded text-xs font-orbitron tracking-wider transition-all
                          ${selectedRound === r
                            ? 'bg-meca-blue text-white'
                            : 'border border-meca-blue/20 text-slate-400 hover:border-meca-blue/50 hover:text-meca-blue'}`}>
                        {ROUND_LABELS[r]}
                      </button>
                    )
                  ))}
                </div>
                {roundMatches.length === 0 ? (
                  <div className="text-center py-12 text-slate-600 font-rajdhani">
                    No hay partidos en esta ronda aún.
                  </div>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-4">
                    {roundMatches.map(m => <MatchCard key={m._id} match={m} />)}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
