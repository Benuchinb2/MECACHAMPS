import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';

export default function NewsDetail() {
  const { id } = useParams();
  const [news, setNews] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/news/${id}`)
      .then(res => setNews(res.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-meca-blue font-orbitron animate-pulse">CARGANDO...</div>
    </div>
  );

  if (!news) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-slate-500 font-rajdhani">Noticia no encontrada</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-3xl mx-auto px-4 py-10">
        <Link to="/noticias" className="text-xs font-orbitron text-slate-600 hover:text-meca-blue transition-colors mb-6 inline-block">
          ← NOTICIAS
        </Link>

        <div className="meca-card overflow-hidden">
          {news.image && (
            <div className="h-72 overflow-hidden">
              <img src={news.image} alt={news.title} className="w-full h-full object-cover" />
            </div>
          )}
          <div className="p-8">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-[10px] font-orbitron text-meca-blue/60 tracking-widest">
                📡 {new Date(news.createdAt).toLocaleDateString('es-AR', { day: '2-digit', month: 'long', year: 'numeric' })}
              </span>
              <span className="text-slate-700">·</span>
              <span className="text-[10px] font-orbitron text-slate-600">{news.author}</span>
            </div>

            <h1 className="font-orbitron font-black text-2xl md:text-3xl text-white mb-6 leading-tight">
              {news.title}
            </h1>

            <div className="meca-divider" />

            <div className="font-exo text-slate-300 leading-relaxed text-base whitespace-pre-wrap">
              {news.content}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
