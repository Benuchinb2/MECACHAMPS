import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';

function TeamCard({ team }) {
  return (
    <Link to={`/equipos/${team._id}`}
      className="meca-card p-5 group block text-center hover:scale-[1.02] transition-transform duration-200">
      {team.shield ? (
        <img src={team.shield} alt={team.name}
          className="w-16 h-16 object-contain mx-auto mb-3 group-hover:scale-110 transition-transform duration-200" />
      ) : (
        <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center font-orbitron font-black text-xl group-hover:scale-110 transition-transform"
          style={{ background: (team.color || '#1e40af') + '22', color: team.color || '#1e40af', border: `2px solid ${team.color || '#1e40af'}44` }}>
          {team.name?.substring(0, 2).toUpperCase()}
        </div>
      )}
      <div className="font-rajdhani font-bold text-slate-200 group-hover:text-meca-blue transition-colors mb-1">
        {team.name}
      </div>
      {team.president && (
        <div className="text-xs font-exo text-slate-600">{team.president}</div>
      )}
    </Link>
  );
}

export default function Teams() {
  const [primera, setPrimera] = useState([]);
  const [segunda, setSegunda] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/teams?division=primera'),
      api.get('/teams?division=segunda'),
    ]).then(([p, s]) => {
      setPrimera(p.data);
      setSegunda(s.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-meca-blue font-orbitron animate-pulse">CARGANDO EQUIPOS...</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-meca-black bg-grid">
      <div className="max-w-7xl mx-auto px-4 py-10">
        <h1 className="meca-section-title mb-2">EQUIPOS</h1>
        <p className="text-slate-500 font-rajdhani mb-10">Todos los clubes participantes · La Meca Champs 2</p>

        <section className="mb-12">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-7 h-7 rounded bg-blue-500/20 border border-blue-500/40 flex items-center justify-center">
              <span className="text-blue-400 text-xs font-orbitron font-bold">1</span>
            </div>
            <h2 className="font-orbitron font-bold text-white text-lg">PRIMERA DIVISIÓN</h2>
            <span className="text-xs font-orbitron text-slate-600">{primera.length}/10 equipos</span>
          </div>
          {primera.length === 0 ? (
            <div className="text-slate-600 font-rajdhani py-8 text-center">No hay equipos en primera. Crea equipos desde el Admin.</div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {primera.map(t => <TeamCard key={t._id} team={t} />)}
            </div>
          )}
        </section>

        <div className="meca-divider" />

        <section>
          <div className="flex items-center gap-3 mb-5">
            <div className="w-7 h-7 rounded bg-slate-500/20 border border-slate-500/40 flex items-center justify-center">
              <span className="text-slate-300 text-xs font-orbitron font-bold">2</span>
            </div>
            <h2 className="font-orbitron font-bold text-white text-lg">SEGUNDA DIVISIÓN</h2>
            <span className="text-xs font-orbitron text-slate-600">{segunda.length}/10 equipos</span>
          </div>
          {segunda.length === 0 ? (
            <div className="text-slate-600 font-rajdhani py-8 text-center">No hay equipos en segunda.</div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {segunda.map(t => <TeamCard key={t._id} team={t} />)}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
