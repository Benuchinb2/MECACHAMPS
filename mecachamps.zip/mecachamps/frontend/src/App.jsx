import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';

// Layout
import Navbar from './components/Navbar';

// Public pages
import Home from './pages/Home';
import Login from './pages/Login';
import PrimeraDivision from './pages/PrimeraDivision';
import SegundaDivision from './pages/SegundaDivision';
import Copa from './pages/Copa';
import Teams from './pages/Teams';
import TeamDetail from './pages/TeamDetail';
import NewsPage from './pages/NewsPage';
import NewsDetail from './pages/NewsDetail';
import Estadisticas from './pages/Estadisticas';

// Admin pages
import AdminDashboard from './pages/admin/AdminDashboard';
import AdminTeams from './pages/admin/AdminTeams';
import AdminPlayers from './pages/admin/AdminPlayers';
import AdminMatches from './pages/admin/AdminMatches';
import AdminNews from './pages/admin/AdminNews';
import AdminCopa from './pages/admin/AdminCopa';
import AdminFixture from './pages/admin/AdminFixture';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-meca-black">
      <div className="text-meca-blue font-orbitron text-lg animate-pulse">CARGANDO...</div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

function AppContent() {
  return (
    <div className="min-h-screen bg-meca-black text-slate-200">
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/primera" element={<PrimeraDivision />} />
          <Route path="/segunda" element={<SegundaDivision />} />
          <Route path="/copa" element={<Copa />} />
          <Route path="/equipos" element={<Teams />} />
          <Route path="/equipos/:id" element={<TeamDetail />} />
          <Route path="/noticias" element={<NewsPage />} />
          <Route path="/noticias/:id" element={<NewsDetail />} />
          <Route path="/estadisticas" element={<Estadisticas />} />
          
          {/* Admin routes */}
          <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
          <Route path="/admin/equipos" element={<ProtectedRoute><AdminTeams /></ProtectedRoute>} />
          <Route path="/admin/jugadores" element={<ProtectedRoute><AdminPlayers /></ProtectedRoute>} />
          <Route path="/admin/partidos" element={<ProtectedRoute><AdminMatches /></ProtectedRoute>} />
          <Route path="/admin/noticias" element={<ProtectedRoute><AdminNews /></ProtectedRoute>} />
          <Route path="/admin/copa" element={<ProtectedRoute><AdminCopa /></ProtectedRoute>} />
          <Route path="/admin/fixture" element={<ProtectedRoute><AdminFixture /></ProtectedRoute>} />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#0a0f1e',
            color: '#e2e8f0',
            border: '1px solid rgba(14, 165, 233, 0.3)',
            fontFamily: 'Rajdhani, sans-serif',
            fontSize: '14px',
          },
          success: { iconTheme: { primary: '#0ea5e9', secondary: '#050810' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#050810' } },
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}
