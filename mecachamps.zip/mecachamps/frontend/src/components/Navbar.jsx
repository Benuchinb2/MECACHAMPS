import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navLinks = [
  { to: '/', label: 'INICIO', icon: '⚡' },
  { to: '/primera', label: '1ª DIV', icon: '🏆' },
  { to: '/segunda', label: '2ª DIV', icon: '🥈' },
  { to: '/copa', label: 'COPA', icon: '🏅' },
  { to: '/equipos', label: 'EQUIPOS', icon: '⚙️' },
  { to: '/estadisticas', label: 'STATS', icon: '📊' },
  { to: '/noticias', label: 'NOTICIAS', icon: '📡' },
];

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 border-b border-meca-blue/20 bg-meca-darker/95 backdrop-blur-sm">
      {/* Top accent bar */}
      <div className="h-0.5 bg-gradient-to-r from-transparent via-meca-blue to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 rounded-full bg-meca-blue/20 group-hover:bg-meca-blue/30 transition-colors animate-pulse-blue" />
              <div className="absolute inset-0 flex items-center justify-center text-meca-blue font-orbitron font-black text-xs">MC</div>
            </div>
            <div>
              <div className="font-orbitron font-black text-white text-sm leading-tight tracking-wider">LA MECA</div>
              <div className="font-orbitron font-bold text-meca-blue text-xs leading-tight tracking-[0.3em]">CHAMPS 2</div>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map(link => {
              const active = location.pathname === link.to || 
                (link.to !== '/' && location.pathname.startsWith(link.to));
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`px-3 py-2 rounded text-xs font-orbitron font-semibold tracking-wider transition-all duration-200
                    ${active
                      ? 'text-meca-blue bg-meca-blue/10 border border-meca-blue/30'
                      : 'text-slate-400 hover:text-meca-blue hover:bg-meca-blue/5'
                    }`}
                >
                  <span className="mr-1">{link.icon}</span>
                  {link.label}
                </Link>
              );
            })}
          </div>

          {/* Auth section */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="hidden lg:flex items-center gap-3">
                <Link
                  to="/admin"
                  className="px-3 py-2 text-xs font-orbitron font-semibold tracking-wider text-yellow-400 hover:text-yellow-300 bg-yellow-900/20 border border-yellow-600/30 rounded transition-all hover:bg-yellow-900/30"
                >
                  ⚡ ADMIN
                </Link>
                <button
                  onClick={handleLogout}
                  className="px-3 py-2 text-xs font-orbitron text-slate-400 hover:text-red-400 transition-colors"
                >
                  SALIR
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                className="hidden lg:block px-3 py-2 text-xs font-orbitron font-semibold tracking-wider text-meca-blue border border-meca-blue/30 rounded hover:bg-meca-blue/10 transition-all"
              >
                🔐 ACCESO
              </Link>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="lg:hidden text-slate-400 hover:text-meca-blue transition-colors p-1"
            >
              {menuOpen ? (
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="lg:hidden border-t border-meca-blue/20 py-3 animate-fade-in">
            {navLinks.map(link => {
              const active = location.pathname === link.to || 
                (link.to !== '/' && location.pathname.startsWith(link.to));
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 text-sm font-orbitron font-semibold tracking-wider transition-all
                    ${active ? 'text-meca-blue bg-meca-blue/10' : 'text-slate-400 hover:text-meca-blue'}`}
                >
                  <span>{link.icon}</span>
                  {link.label}
                </Link>
              );
            })}
            <div className="border-t border-meca-blue/20 mt-2 pt-2">
              {user ? (
                <>
                  <Link to="/admin" onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 text-sm font-orbitron text-yellow-400">
                    ⚡ PANEL ADMIN
                  </Link>
                  <button onClick={handleLogout}
                    className="flex items-center gap-3 px-4 py-3 text-sm font-orbitron text-red-400 w-full">
                    🚪 CERRAR SESIÓN
                  </button>
                </>
              ) : (
                <Link to="/login" onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 text-sm font-orbitron text-meca-blue">
                  🔐 ACCESO ADMIN
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
