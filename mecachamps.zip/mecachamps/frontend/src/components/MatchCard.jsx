import React from 'react';
import { Link } from 'react-router-dom';

export default function MatchCard({ match, compact = false }) {
  if (!match) return null;

  const { homeTeam, awayTeam, homeScore, awayScore, played, date, round, leg } = match;

  const formatDate = (d) => {
    if (!d) return 'Fecha TBD';
    return new Date(d).toLocaleDateString('es-AR', {
      day: '2-digit', month: 'short', year: 'numeric'
    });
  };

  const TeamDisplay = ({ team, isHome }) => {
    if (!team) return (
      <div className={`flex items-center gap-2 ${isHome ? 'justify-end' : 'justify-start'}`}>
        <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center text-slate-600 text-xs">?</div>
        <span className="font-rajdhani text-slate-500 text-sm">Por definir</span>
      </div>
    );

    return (
      <div className={`flex items-center gap-2 ${isHome ? 'flex-row-reverse' : ''}`}>
        {team.shield ? (
          <img src={team.shield} alt={team.name} className="w-8 h-8 object-contain" />
        ) : (
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0"
            style={{ background: (team.color || '#1e40af') + '33', color: team.color || '#1e40af', border: `1px solid ${team.color || '#1e40af'}55` }}>
            {team.name?.substring(0, 2).toUpperCase()}
          </div>
        )}
        <Link to={`/equipos/${team._id}`}
          className={`font-rajdhani font-semibold text-sm text-slate-200 hover:text-meca-blue transition-colors ${isHome ? 'text-right' : ''}`}>
          {team.name}
        </Link>
      </div>
    );
  };

  return (
    <div className={`meca-card transition-all duration-200 ${compact ? 'p-3' : 'p-4'}`}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-orbitron text-meca-blue/70 tracking-wider">{round}</span>
          {leg === 2 && (
            <span className="text-[9px] font-orbitron px-1.5 py-0.5 rounded border border-meca-blue/20 text-meca-blue/60">VUELTA</span>
          )}
        </div>
        <span className="text-[10px] text-slate-600 font-exo">{formatDate(date)}</span>
      </div>

      {/* Score */}
      <div className="grid grid-cols-3 items-center gap-2">
        <TeamDisplay team={homeTeam} isHome={true} />
        
        <div className="flex items-center justify-center">
          {played ? (
            <div className="flex items-center gap-2">
              <span className="font-orbitron font-black text-2xl text-white">{homeScore}</span>
              <span className="font-orbitron text-meca-blue/50 text-lg">-</span>
              <span className="font-orbitron font-black text-2xl text-white">{awayScore}</span>
            </div>
          ) : (
            <div className="flex items-center justify-center w-16 h-10 border border-meca-blue/20 rounded bg-meca-darker">
              <span className="font-orbitron text-meca-blue/40 text-xs tracking-wider">VS</span>
            </div>
          )}
        </div>
        
        <TeamDisplay team={awayTeam} isHome={false} />
      </div>

      {/* Status */}
      {!played && (
        <div className="mt-3 flex justify-center">
          <span className="text-[10px] font-orbitron text-slate-600 tracking-wider border border-slate-700 rounded px-2 py-0.5">
            PENDIENTE
          </span>
        </div>
      )}
    </div>
  );
}
