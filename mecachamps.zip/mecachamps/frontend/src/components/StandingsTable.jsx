import React from 'react';
import { Link } from 'react-router-dom';

export default function StandingsTable({ standings = [], division = 'primera', loading = false }) {
  const getRowClass = (index, division) => {
    if (index === 0) return 'pos-champion';
    if (division === 'segunda' && index === 1) return 'pos-promote';
    if (division === 'primera') {
      const last = standings.length;
      if (index >= last - 2) return 'pos-relegate';
    }
    return '';
  };

  const getBadge = (index, division) => {
    if (index === 0) return <span className="text-[10px] px-1.5 py-0.5 rounded font-orbitron font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">CAMPEÓN</span>;
    if (division === 'segunda' && index === 1) return <span className="text-[10px] px-1.5 py-0.5 rounded font-orbitron font-bold bg-green-500/20 text-green-400 border border-green-500/30">ASCIENDE</span>;
    if (division === 'primera' && index >= standings.length - 2) return <span className="text-[10px] px-1.5 py-0.5 rounded font-orbitron font-bold bg-red-500/20 text-red-400 border border-red-500/30">DESCIENDE</span>;
    return null;
  };

  if (loading) return (
    <div className="flex items-center justify-center py-16">
      <div className="text-meca-blue font-orbitron text-sm animate-pulse">CARGANDO TABLA...</div>
    </div>
  );

  if (!standings.length) return (
    <div className="text-center py-12 text-slate-600 font-rajdhani">
      <div className="text-4xl mb-3">📋</div>
      <div className="text-lg">No hay datos disponibles aún</div>
      <div className="text-sm mt-1">Genera el fixture y carga resultados para ver la tabla</div>
    </div>
  );

  const headers = ['POS', 'EQUIPO', 'PJ', 'PG', 'PE', 'PP', 'GF', 'GC', 'DF', 'PTS'];

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-meca-blue/20">
            {headers.map(h => (
              <th key={h} className="px-3 py-3 text-left text-[10px] font-orbitron font-semibold text-meca-blue/70 tracking-widest">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {standings.map((row, index) => (
            <tr key={row.team._id} className={`table-row-hover border-b border-meca-blue/5 ${getRowClass(index, division)}`}>
              <td className="px-3 py-3">
                <span className="font-orbitron font-bold text-slate-400 text-xs">{index + 1}</span>
              </td>
              <td className="px-3 py-3">
                <div className="flex items-center gap-2">
                  {row.team.shield ? (
                    <img src={row.team.shield} alt={row.team.name} className="w-6 h-6 object-contain rounded" />
                  ) : (
                    <div className="w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold"
                      style={{ background: row.team.color + '33', color: row.team.color }}>
                      {row.team.name?.substring(0, 2).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <Link
                      to={`/equipos/${row.team._id}`}
                      className="font-rajdhani font-semibold text-slate-200 hover:text-meca-blue transition-colors"
                    >
                      {row.team.name}
                    </Link>
                    <div className="hidden sm:block">{getBadge(index, division)}</div>
                  </div>
                </div>
              </td>
              <td className="px-3 py-3 text-center font-exo text-slate-400">{row.pj}</td>
              <td className="px-3 py-3 text-center font-exo text-green-400">{row.pg}</td>
              <td className="px-3 py-3 text-center font-exo text-yellow-400">{row.pe}</td>
              <td className="px-3 py-3 text-center font-exo text-red-400">{row.pp}</td>
              <td className="px-3 py-3 text-center font-exo text-slate-300">{row.gf}</td>
              <td className="px-3 py-3 text-center font-exo text-slate-300">{row.gc}</td>
              <td className={`px-3 py-3 text-center font-exo font-semibold ${row.df > 0 ? 'text-green-400' : row.df < 0 ? 'text-red-400' : 'text-slate-400'}`}>
                {row.df > 0 ? `+${row.df}` : row.df}
              </td>
              <td className="px-3 py-3 text-center">
                <span className="font-orbitron font-black text-white text-base">{row.pts}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 p-4 border-t border-meca-blue/10 text-[10px] font-orbitron">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-sm bg-blue-500/30 border border-blue-500/50" />
          <span className="text-slate-500">Campeón</span>
        </div>
        {division === 'segunda' && (
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-green-500/30 border border-green-500/50" />
            <span className="text-slate-500">Asciende</span>
          </div>
        )}
        {division === 'primera' && (
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-sm bg-red-500/30 border border-red-500/50" />
            <span className="text-slate-500">Desciende</span>
          </div>
        )}
      </div>
    </div>
  );
}
