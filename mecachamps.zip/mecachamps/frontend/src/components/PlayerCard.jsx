import React from 'react';
import { Link } from 'react-router-dom';

export default function PlayerCard({ player, showTeam = true, compact = false }) {
  if (!player) return null;

  const getRatingColor = (rating) => {
    if (rating >= 85) return '#f59e0b'; // gold
    if (rating >= 75) return '#0ea5e9'; // blue
    if (rating >= 65) return '#22c55e'; // green
    return '#64748b'; // gray
  };

  const ratingColor = getRatingColor(player.rating);

  if (compact) {
    return (
      <div className="flex items-center gap-3 p-2 rounded border border-meca-blue/10 hover:border-meca-blue/30 transition-all bg-meca-darker/50">
        {player.photo ? (
          <img src={player.photo} alt={player.name} className="w-8 h-8 rounded-full object-cover border border-meca-blue/20" />
        ) : (
          <div className="w-8 h-8 rounded-full bg-meca-gray flex items-center justify-center text-sm font-bold text-meca-blue/60">
            {player.name?.charAt(0)}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="font-rajdhani font-semibold text-sm text-slate-200 truncate">{player.name}</div>
          <div className="text-xs text-slate-500 font-exo">{player.position} · {player.age}a</div>
        </div>
        <div className="font-orbitron font-black text-sm" style={{ color: ratingColor }}>
          {player.rating}
        </div>
      </div>
    );
  }

  return (
    <div className="meca-card p-4 flex flex-col items-center text-center group">
      {/* Photo */}
      <div className="relative mb-3">
        {player.photo ? (
          <img src={player.photo} alt={player.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-meca-blue/30 group-hover:border-meca-blue/60 transition-colors" />
        ) : (
          <div className="w-16 h-16 rounded-full bg-meca-gray border-2 border-meca-blue/20 flex items-center justify-center text-2xl font-bold text-meca-blue/40">
            {player.name?.charAt(0)}
          </div>
        )}
        {/* Rating badge */}
        <div className="absolute -top-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-orbitron font-black border-2"
          style={{ background: ratingColor + '22', color: ratingColor, borderColor: ratingColor + '88' }}>
          {player.rating}
        </div>
      </div>

      {/* Name */}
      <div className="font-rajdhani font-bold text-sm text-slate-200 mb-0.5">{player.name}</div>
      
      {/* Position & age */}
      <div className="text-[11px] font-exo text-slate-500 mb-2">
        {player.position} · {player.age} años · #{player.number}
      </div>

      {/* Team */}
      {showTeam && player.team && (
        <Link to={`/equipos/${player.team._id}`}
          className="text-[10px] font-orbitron text-meca-blue/70 hover:text-meca-blue mb-3 transition-colors">
          {player.team.name}
        </Link>
      )}

      {/* Stats */}
      <div className="w-full grid grid-cols-4 gap-1 mt-2 border-t border-meca-blue/10 pt-2">
        <div className="text-center">
          <div className="font-orbitron font-black text-sm text-white">{player.goalsLeague + player.goalsCopa}</div>
          <div className="text-[9px] font-orbitron text-slate-600">GOL</div>
        </div>
        <div className="text-center">
          <div className="font-orbitron font-black text-sm text-meca-blue">{player.assistsLeague + player.assistsCopa}</div>
          <div className="text-[9px] font-orbitron text-slate-600">ASI</div>
        </div>
        <div className="text-center">
          <div className="font-orbitron font-black text-sm text-yellow-400">{player.yellowCardsLeague + player.yellowCardsCopa}</div>
          <div className="text-[9px] font-orbitron text-slate-600">AM</div>
        </div>
        <div className="text-center">
          <div className="font-orbitron font-black text-sm text-red-400">{player.redCardsLeague + player.redCardsCopa}</div>
          <div className="text-[9px] font-orbitron text-slate-600">RJ</div>
        </div>
      </div>
    </div>
  );
}
